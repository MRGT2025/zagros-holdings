import { AsyncLocalStorage } from "node:async_hooks";

export type CmsEnv = Cloudflare.Env;

type CmsGlobal = typeof globalThis & {
  __zagrosCmsEnvStorage?: AsyncLocalStorage<CmsEnv>;
};

const cmsGlobal = globalThis as CmsGlobal;
const cmsEnvStorage = cmsGlobal.__zagrosCmsEnvStorage ??= new AsyncLocalStorage<CmsEnv>();

export function runWithCmsEnv<T>(env: CmsEnv, callback: () => T): T {
  return cmsEnvStorage.run(env, callback);
}

export function getCmsEnv(): CmsEnv {
  const current = cmsEnvStorage.getStore();
  if (!current) throw new Error("محیط ذخیره‌سازی سایت در دسترس نیست.");
  return current;
}
