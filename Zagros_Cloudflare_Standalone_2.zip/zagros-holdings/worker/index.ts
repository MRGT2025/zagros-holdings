/** Standalone Cloudflare Worker entry point. */
import handler from "vinext/server/app-router-entry";
import { runWithCmsEnv, type CmsEnv } from "./cms-env";

// Image security config. SVG sources with .svg extension auto-skip the
// optimization endpoint on the client side (served directly, no proxy).
// To route SVGs through the optimizer (with security headers), set
// dangerouslyAllowSVG: true in next.config.js and uncomment below:
// const imageConfig: ImageConfig = { dangerouslyAllowSVG: true };

const worker = {
  async fetch(request: Request, env: CmsEnv, ctx: ExecutionContext): Promise<Response> {
    return runWithCmsEnv(env, () => handler.fetch(request, env, ctx));
  },
} satisfies ExportedHandler<CmsEnv>;

export default worker;
