import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const admins = sqliteTable("admins", {
  id: text("id").primaryKey(),
  email: text("email").notNull().unique(),
  name: text("name").notNull().default(""),
  role: text("role").notNull().default("editor"),
  status: text("status").notNull().default("pending"),
  createdAt: integer("created_at").notNull(),
});

export const pages = sqliteTable("pages", {
  slug: text("slug").primaryKey(),
  title: text("title").notNull(),
  menuLabel: text("menu_label").notNull(),
  description: text("description").notNull().default(""),
  status: text("status").notNull().default("draft"),
  contentJson: text("content_json").notNull(),
  updatedAt: integer("updated_at").notNull(),
  updatedBy: text("updated_by").notNull().default(""),
});

export const pageRevisions = sqliteTable("page_revisions", {
  id: text("id").primaryKey(),
  pageSlug: text("page_slug").notNull(),
  contentJson: text("content_json").notNull(),
  createdAt: integer("created_at").notNull(),
  createdBy: text("created_by").notNull().default(""),
});

export const siteSettings = sqliteTable("site_settings", {
  settingKey: text("setting_key").primaryKey(),
  valueJson: text("value_json").notNull(),
  updatedAt: integer("updated_at").notNull(),
});

export const media = sqliteTable("media", {
  id: text("id").primaryKey(),
  objectKey: text("object_key").notNull().unique(),
  filename: text("filename").notNull(),
  mimeType: text("mime_type").notNull(),
  size: integer("size").notNull(),
  uploadedBy: text("uploaded_by").notNull(),
  createdAt: integer("created_at").notNull(),
});

