# Zagros Holdings — Cloudflare standalone

The Zagros Holdings website and its visual CMS run independently on Cloudflare
Workers. The application does not depend on ChatGPT or WordPress at runtime.

## Architecture

- Cloudflare Worker: public website, CMS UI and server APIs
- D1 (`DB`): pages, sections, settings, admins and revision history
- R2 (`BUCKET`): uploaded images and video
- Cloudflare Access: authenticated identity for `/admin*` and
  `/api/admin/*`
- CMS roles: owner, admin, editor and viewer

The public site, `/api/cms/public` and `/media/*` stay public. CMS authorization
is checked again inside the application, so an authenticated email must also be
present in the CMS admin list.

## Requirements

- Node.js `>=22.13.0`
- A Cloudflare account with Workers, D1, R2 and Zero Trust enabled
- Wrangler authenticated with `wrangler login`, or equivalent Cloudflare API
  access in the deployment environment

## Install and verify

```bash
npm ci
npm run cf:types
npm run lint
npx tsc --noEmit
npm run build
npx wrangler deploy --dry-run
```

`wrangler types` generates `worker-configuration.d.ts` from `wrangler.jsonc`.
Run it again after changing a binding or environment variable.

## Create Cloudflare resources

Create the database and copy the returned database ID into the `database_id`
field in `wrangler.jsonc`:

```bash
npx wrangler d1 create zagros-holdings-cms
npx wrangler r2 bucket create zagros-holdings-media
```

Apply the checked-in schema:

```bash
npx wrangler d1 migrations apply zagros-holdings-cms --remote
```

The application also verifies and seeds the required tables on first request.
The permanent owner email comes from `OWNER_EMAIL` and defaults to
`info@mrgt.co`.

## Configure Cloudflare Access

Create a self-hosted Access application that protects both paths:

- `zagrostejarat.co/admin*`
- `zagrostejarat.co/api/admin/*`

Use an identity provider such as One-time PIN. An `Everyone` authentication
policy is acceptable because the application itself rejects every email that
is not in the CMS admin list.

Set these values in `wrangler.jsonc`:

- `CF_ACCESS_TEAM_DOMAIN`: the Zero Trust team domain, for example
  `https://example.cloudflareaccess.com`
- `CF_ACCESS_AUD`: the Access application AUD tag

The Worker validates the `Cf-Access-Jwt-Assertion` signature, issuer and
audience before trusting an identity.

## Deploy

```bash
npm run deploy
```

Test the generated `workers.dev` address before attaching the production
domain. Then add `zagrostejarat.co` as a Worker Custom Domain. Cloudflare will
create the Worker DNS record and issue SSL for the hostname.

## Admin workflow

1. Open `/admin` and sign in with `info@mrgt.co`.
2. Add or remove admin emails from **مدیران و سطح دسترسی**.
3. Edit pages, sections, text, images, video, galleries, cards, tables and FAQs
   while using the live preview.
4. Publish the changes from the CMS.

Uploaded media is stored in R2 and delivered publicly through `/media/<key>`.
