"use client";
/* eslint-disable @next/next/no-img-element */

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import type { CmsBlock, CmsItem, CmsPage, CmsSettings } from "../lib/cms";
import { defaultPages, defaultSettings } from "../lib/cms";

type PublicPayload = { pages: CmsPage[]; settings: CmsSettings };
const pageHref = (slug: string) => (slug === "home" ? "/" : `/${slug}`);

function Arrow() { return <span aria-hidden="true">↙</span>; }

function MotionIntro({ settings, onDone }: { settings: CmsSettings; onDone: () => void }) {
  const [leaving, setLeaving] = useState(false);

  useEffect(() => {
    const timer = window.setTimeout(() => setLeaving(true), Math.max(2800, settings.introDuration || 4600));
    return () => window.clearTimeout(timer);
  }, [settings.introDuration]);

  useEffect(() => {
    if (!leaving) return;
    const timer = window.setTimeout(onDone, 950);
    return () => window.clearTimeout(timer);
  }, [leaving, onDone]);

  return <div className={`brand-intro ${leaving ? "leaving" : ""}`} role="dialog" aria-label="معرفی هلدینگ زاگرس">
    <img className="brand-intro__image" src="/isfahan.webp" alt="" />
    <div className="brand-intro__shade" />
    <div className="brand-intro__grid" />
    <div className="brand-intro__sweep" />
    <div className="brand-intro__rails"><i /><i /><i /></div>
    <div className="brand-intro__corners"><i /><i /><i /><i /></div>
    <div className="brand-intro__main">
      <small>{settings.introKicker}</small>
      <strong aria-label={settings.introTitle}>{settings.introTitle.split("").map((letter, index) => <span style={{ "--letter": index } as React.CSSProperties} key={`${letter}-${index}`}>{letter}</span>)}</strong>
      <h2>{settings.introSubtitle} <em>{settings.introAccent}</em></h2>
      <div className="brand-intro__progress"><i /></div>
      <p><span>01</span> ORIGIN INTELLIGENCE <span>02</span> QUALITY CONTROL <span>03</span> GLOBAL LOGISTICS</p>
    </div>
    <button onClick={() => setLeaving(true)}>ورود به زاگرس <Arrow /></button>
    <div className="brand-intro__index">ZAGROS / 2026 / ISFAHAN</div>
  </div>;
}

function SectionHead({ block }: { block: CmsBlock }) {
  return <header className="public-section__head motion-reveal">
    {block.eyebrow && <span className="public-eyebrow"><i />{block.eyebrow}</span>}
    <h2>{block.title}</h2>
    {block.body && <p>{block.body}</p>}
  </header>;
}

function BlockView({ block }: { block: CmsBlock }) {
  if (!block.visible) return null;
  if (block.type === "hero") return <section className="public-hero">
    <div className="public-hero__image"><img src={block.image || "/isfahan.webp"} alt="شبکه تجارت کالای هلدینگ زاگرس" /></div>
    <div className="public-hero__veil" /><div className="hero-orbit"><i /><i /><i /></div>
    <div className="public-wrap public-hero__content">
      <span className="public-eyebrow hero-kicker"><i />{block.eyebrow}</span>
      <h1><span>{block.title}</span><em>{block.accent}</em></h1><p>{block.body}</p>
      <div className="public-actions">{block.buttonText && <a className="public-button" href={block.buttonLink || "#"}>{block.buttonText}<Arrow /></a>}{block.secondaryText && <a className="public-link" href={block.secondaryLink || "#"}>{block.secondaryText} ←</a>}</div>
    </div>
    <div className="public-hero__marker"><b>ZAGROS</b><span>COMMODITY · TRADE · CONTROL</span></div>
  </section>;

  if (block.type === "stats") return <section className={`public-section public-section--${block.tone || "soft"}`}><div className="public-wrap public-stats motion-reveal">{(block.items || []).map((item, index) => <article key={`${item.title}-${index}`}><strong>{item.title}</strong><span>{item.subtitle}</span></article>)}</div></section>;

  if (block.type === "text") return <section className={`public-section public-section--${block.tone || "light"}`}><div className="public-wrap public-editorial motion-reveal"><div><span className="public-eyebrow"><i />{block.eyebrow}</span><h2>{block.title}</h2></div><p>{block.body}</p></div></section>;

  if (block.type === "cards") return <section className={`public-section public-section--${block.tone || "light"}`}><div className="public-wrap"><SectionHead block={block} /><div className={`public-cards ${(block.items || []).length > 4 ? "public-cards--dense" : ""}`}>{(block.items || []).map((item, index) => {
    const content = <>{item.image && <div className="public-card__image"><img src={item.image} alt="" /><span className="public-card__count">{String(index + 1).padStart(2, "0")}</span></div>}<div className="public-card__body"><small>{item.subtitle || String(index + 1).padStart(2, "0")}</small><h3>{item.title}</h3><p>{item.body}</p>{item.origin && <dl><div><dt>مبدأ</dt><dd>{item.origin}</dd></div><div><dt>حداقل سفارش</dt><dd>{item.moq}</dd></div></dl>}<span className="public-card__arrow">↖</span></div></>;
    return item.link ? <a className="public-card motion-reveal" href={item.link} key={`${item.title}-${index}`}>{content}</a> : <article className="public-card motion-reveal" style={{ "--card-delay": `${index * 70}ms`, "--accent": item.accent || "#f49a45" } as React.CSSProperties} key={`${item.title}-${index}`}>{content}</article>;
  })}</div></div></section>;

  if (block.type === "image") return <section className={`public-section public-section--${block.tone || "light"}`}><div className="public-wrap public-feature-image motion-reveal"><img src={block.image || "/zagros-holding-hero-v2.png"} alt={block.title || ""} /><div><span className="public-eyebrow"><i />{block.eyebrow}</span><h2>{block.title}</h2><p>{block.body}</p></div></div></section>;

  if (block.type === "video") return <section className={`public-section public-section--${block.tone || "brand"}`}><div className="public-wrap public-video motion-reveal"><SectionHead block={block} /><div className="public-video__frame">{block.videoUrl ? <video src={block.videoUrl} poster={block.image} controls={!block.autoplay} autoPlay={block.autoplay} muted={block.muted ?? true} loop={block.loop} playsInline /> : <div className="public-video__empty" style={{ backgroundImage: `url(${block.image || "/isfahan.webp"})` }}><span>▶</span><p>ویدیو را از پنل مدیریت بارگذاری کنید</p></div>}<i className="public-video__line" /></div></div></section>;

  if (block.type === "gallery") return <section className={`public-section public-section--${block.tone || "light"}`}><div className="public-wrap"><SectionHead block={block} /><div className="public-gallery">{(block.items || []).map((item, index) => <figure className="motion-reveal" key={`${item.title}-${index}`}><img src={item.image || "/coffee.webp"} alt={item.title} /><figcaption><span>{String(index + 1).padStart(2, "0")}</span>{item.title}</figcaption></figure>)}</div></div></section>;

  if (block.type === "faq") return <section className={`public-section public-section--${block.tone || "soft"}`}><div className="public-wrap public-faq"><SectionHead block={block} /><div>{(block.items || []).map((item, index) => <details className="motion-reveal" key={`${item.title}-${index}`}><summary><span>{String(index + 1).padStart(2, "0")}</span>{item.title}<i>+</i></summary><p>{item.body}</p></details>)}</div></div></section>;

  if (block.type === "table") return <section className={`public-section public-section--${block.tone || "soft"}`}><div className="public-wrap"><SectionHead block={block} /><div className="public-table-wrap motion-reveal"><table className="public-table"><thead><tr>{(block.columns || []).map((cell, i) => <th key={i}>{cell}</th>)}</tr></thead><tbody>{(block.rows || []).map((row, i) => <tr key={i}>{row.map((cell, j) => <td key={j}>{cell}</td>)}</tr>)}</tbody></table></div></div></section>;

  return <section className={`public-section public-section--${block.tone || "brand"}`}><div className="public-wrap public-cta motion-reveal"><div><span className="public-eyebrow"><i />{block.eyebrow}</span><h2>{block.title}</h2><p>{block.body}</p></div>{block.buttonText && <a className="public-button" href={block.buttonLink || "#"}>{block.buttonText}<Arrow /></a>}</div></section>;
}

function WholesaleShop({ products, cart, onToggle }: { products: CmsItem[]; cart: string[]; onToggle: (id: string) => void }) {
  const [filter, setFilter] = useState("همه");
  const categories = ["همه", ...Array.from(new Set(products.map((item) => item.category || "سایر")))];
  const visible = filter === "همه" ? products : products.filter((item) => item.category === filter);
  return <section className="wholesale-shop public-section"><div className="public-wrap"><div className="shop-tools motion-reveal"><div><span className="public-eyebrow"><i />WHOLESALE QUOTE STORE</span><h2>سبد خرید و استعلام عمده</h2><p>{products.length.toLocaleString("fa-IR")} محصول فعال؛ قیمت براساس حجم، گرید، مبدأ و تحویل.</p></div><div className="shop-filters">{categories.map((category) => <button className={filter === category ? "active" : ""} onClick={() => setFilter(category)} key={category}>{category}</button>)}</div></div><div className="shop-grid">{visible.map((product, index) => { const id = product.subtitle || product.title; const added = cart.includes(id); return <article className="shop-card motion-reveal" style={{ "--accent": product.accent || "#f49a45", "--card-delay": `${index * 60}ms` } as React.CSSProperties} key={id}><div className="shop-card__media"><img src={product.image || "/coffee.webp"} alt={product.title} /><span>{product.category}</span><i>{String(index + 1).padStart(2, "0")}</i></div><div className="shop-card__body"><small>{product.subtitle}</small><h3>{product.title}</h3><p>{product.body}</p><dl><div><dt>مبدأ</dt><dd>{product.origin}</dd></div><div><dt>حداقل سفارش</dt><dd>{product.moq}</dd></div></dl></div><button className={added ? "added" : ""} onClick={() => onToggle(id)}><span>{added ? "حذف از سبد" : "افزودن به سبد استعلام"}</span><i>{added ? "✓" : "+"}</i></button></article>; })}</div></div></section>;
}

function QuoteCart({ products, cart, open, setOpen, remove, settings }: { products: CmsItem[]; cart: string[]; open: boolean; setOpen: (value: boolean) => void; remove: (id: string) => void; settings: CmsSettings }) {
  const selected = cart.map((id) => products.find((item) => (item.subtitle || item.title) === id)).filter(Boolean) as CmsItem[];
  const message = ["سلام، برای محصولات زیر درخواست قیمت و شرایط تأمین دارم:", "", ...selected.map((item, index) => `${index + 1}. ${item.title} (${item.subtitle}) — مبدأ: ${item.origin}`), "", "ارسال‌شده از وب‌سایت هلدینگ زاگرس"].join("\n");
  return <><button className="quote-float" onClick={() => setOpen(true)}><span className="cart-icon">♢<em>{cart.length.toLocaleString("fa-IR")}</em></span><div><small>WHOLESALE CART</small><b>سبد استعلام قیمت</b></div><i>←</i></button><div className={`cart-overlay ${open ? "open" : ""}`} onClick={() => setOpen(false)} /><aside className={`cart-drawer ${open ? "open" : ""}`}><header><div><small>WHOLESALE QUOTE DESK</small><h2>سبد درخواست قیمت</h2></div><button onClick={() => setOpen(false)}>×</button></header><div className="cart-items">{selected.length ? selected.map((item) => <article className="cart-item" key={item.subtitle || item.title}><div><h3>{item.title}</h3><p>{item.subtitle} · {item.origin}</p></div><button onClick={() => remove(item.subtitle || item.title)}>حذف</button></article>) : <div className="cart-empty"><b>سبد شما خالی است.</b><p>از فروشگاه، قهوه، ادویه یا خشکبار موردنظر را انتخاب کنید.</p></div>}</div>{selected.length > 0 && <div className="cart-checkout"><p>فهرست شما آماده است. با دکمه زیر، متن کامل استعلام برای واتساپ آماده می‌شود.</p><a href={`https://wa.me/${settings.whatsapp}?text=${encodeURIComponent(message)}`} target="_blank" rel="noreferrer"><span>ارسال فهرست در واتساپ</span><i>↖</i></a></div>}</aside></>;
}

export default function PublicSite({ slug = "home", previewPage }: { slug?: string; previewPage?: CmsPage }) {
  const [data, setData] = useState<PublicPayload>({ pages: defaultPages, settings: defaultSettings });
  const [menuOpen, setMenuOpen] = useState(false);
  const [introVisible, setIntroVisible] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const [cart, setCart] = useState<string[]>([]);
  const [cartHydrated, setCartHydrated] = useState(false);

  useEffect(() => { if (previewPage) return; fetch("/api/cms/public").then(async (response) => response.ok ? await response.json() as PublicPayload : Promise.reject()).then((payload) => setData(payload)).catch(() => undefined); }, [previewPage]);
  useEffect(() => {
    if (previewPage || slug !== "home") return;
    const frame = window.requestAnimationFrame(() => setIntroVisible(!window.sessionStorage.getItem("zagros-brand-intro-v3")));
    return () => window.cancelAnimationFrame(frame);
  }, [previewPage, slug]);
  useEffect(() => {
    const frame = window.requestAnimationFrame(() => {
      try { setCart(JSON.parse(window.localStorage.getItem("zagros-quote-cart-v3") || "[]") as string[]); }
      catch { setCart([]); }
      setCartHydrated(true);
    });
    return () => window.cancelAnimationFrame(frame);
  }, []);
  useEffect(() => { if (cartHydrated) window.localStorage.setItem("zagros-quote-cart-v3", JSON.stringify(cart)); }, [cart, cartHydrated]);
  useEffect(() => { const observer = new IntersectionObserver((entries) => entries.forEach((entry) => { if (entry.isIntersecting) { entry.target.classList.add("in"); observer.unobserve(entry.target); } }), { threshold: .12 }); document.querySelectorAll(".motion-reveal").forEach((element) => observer.observe(element)); return () => observer.disconnect(); }, [data, slug]);

  const page = useMemo(() => previewPage || data.pages.find((item) => item.slug === slug) || data.pages[0], [data.pages, previewPage, slug]);
  const menuPages = data.pages.filter((item) => item.status === "published");
  const shopPage = previewPage?.slug === "shop" ? previewPage : data.pages.find((item) => item.slug === "shop") || defaultPages.find((item) => item.slug === "shop");
  const products = shopPage?.blocks.find((block) => block.id === "shop-products")?.items || data.pages.find((item) => item.slug === "products")?.blocks.find((block) => block.id === "products-grid")?.items || [];
  const toggleCart = (id: string) => setCart((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  const finishIntro = () => { window.sessionStorage.setItem("zagros-brand-intro-v3", "seen"); setIntroVisible(false); };

  return <div className="public-site" dir="rtl">
    {introVisible && data.settings.introEnabled && <MotionIntro settings={data.settings} onDone={finishIntro} />}
    <header className="public-header"><Link className="public-brand" href="/" aria-label="هلدینگ زاگرس"><img src="/logo.jpeg" alt="" /><span><b>{data.settings.brandName}</b><small>{data.settings.brandDescriptor}</small></span></Link><nav className={menuOpen ? "open" : ""} aria-label="منوی اصلی">{menuPages.map((item) => <a className={item.slug === page.slug ? "active" : ""} href={pageHref(item.slug)} key={item.slug}>{item.menuLabel}</a>)}</nav><Link className="public-header__cta" href="/contact">درخواست تأمین <Arrow /></Link><button className="public-menu" onClick={() => setMenuOpen(!menuOpen)} aria-label="باز کردن منو">{menuOpen ? "×" : "☰"}</button></header>
    <main className="page-enter">{page.slug === "shop" ? <>{page.blocks.filter((block) => block.type === "hero").map((block) => <BlockView block={block} key={block.id} />)}<WholesaleShop products={products} cart={cart} onToggle={toggleCart} />{page.blocks.filter((block) => block.type !== "hero" && block.id !== "shop-products").map((block) => <BlockView block={block} key={block.id} />)}</> : page.blocks.map((block) => <BlockView block={block} key={block.id} />)}</main>
    <footer className="public-footer"><div className="public-wrap public-footer__top"><Link className="public-brand public-footer__logo" href="/"><img src="/logo.jpeg" alt="" /><span><b>{data.settings.brandName}</b><small>{data.settings.brandDescriptor}</small></span></Link><div><span className="public-eyebrow"><i />COMMODITY TRADE</span><h2>{data.settings.footerLine}</h2></div><div className="public-footer__contact"><small>ISFAHAN TRADE DESK</small><a href={`mailto:${data.settings.email}`}>{data.settings.email}</a><span>{data.settings.location}</span></div></div><div className="public-footer__bottom"><span>© 2026 ZAGROS HOLDING · ISFAHAN</span><Link href="/admin">ورود مدیران</Link></div></footer>
    <QuoteCart products={products} cart={cart} open={cartOpen} setOpen={setCartOpen} remove={(id) => setCart((current) => current.filter((item) => item !== id))} settings={data.settings} />
  </div>;
}
