"use client";
/* eslint-disable @next/next/no-img-element */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import PublicSite from "./PublicSite";
import {
  blockTemplates,
  cloneDefaults,
  defaultSettings,
  type AdminRecord,
  type BlockType,
  type CmsBlock,
  type CmsPage,
  type CmsSettings,
} from "../lib/cms";

type StudioPayload = { pages: CmsPage[]; settings: CmsSettings; admins: AdminRecord[]; currentAdmin?: AdminRecord };
type ApiResult = { error?: string; admins?: AdminRecord[]; mime?: string; url?: string; [key: string]: unknown };
type StudioView = "overview" | "builder" | "admins" | "media" | "settings";

const viewLabels: Record<StudioView, string> = {
  overview: "داشبورد",
  builder: "ویرایش همه صفحات",
  admins: "مدیران و دسترسی‌ها",
  media: "رسانه‌ها",
  settings: "تنظیمات سایت",
};

const blockLabels: Record<BlockType, string> = {
  hero: "هدر تصویری",
  text: "متن آزاد",
  stats: "آمار",
  cards: "کارت و سطر",
  image: "تصویر",
  video: "ویدیو",
  gallery: "گالری",
  faq: "سؤالات متداول",
  table: "جدول",
  cta: "دعوت به اقدام",
};

const blockIcon: Record<BlockType, string> = { hero: "▣", text: "¶", stats: "◫", cards: "▦", image: "▧", video: "▶", gallery: "▥", faq: "?", table: "▤", cta: "↗" };

function uid(prefix = "block") {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

function jsonClone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T;
}

export default function AdminStudio({ currentUser }: { currentUser: { email: string; displayName: string } }) {
  const [view, setView] = useState<StudioView>("overview");
  const [pages, setPages] = useState<CmsPage[]>(cloneDefaults());
  const [settings, setSettings] = useState<CmsSettings>(defaultSettings);
  const [admins, setAdmins] = useState<AdminRecord[]>([]);
  const [pageSlug, setPageSlug] = useState("home");
  const [selectedBlockId, setSelectedBlockId] = useState("home-hero");
  const [previewMode, setPreviewMode] = useState<"desktop" | "mobile">("desktop");
  const [saveState, setSaveState] = useState<"saved" | "dirty" | "saving">("saved");
  const [notice, setNotice] = useState("");
  const [adminEmail, setAdminEmail] = useState("");
  const [adminRole, setAdminRole] = useState<AdminRecord["role"]>("editor");
  const [uploading, setUploading] = useState(false);
  const [canUndo, setCanUndo] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);
  const history = useRef<CmsPage[][]>([]);

  const showNotice = useCallback((text: string) => {
    setNotice(text);
    window.setTimeout(() => setNotice(""), 2600);
  }, []);

  useEffect(() => {
    fetch("/api/admin/cms")
      .then(async (response) => response.ok ? await response.json() as StudioPayload : Promise.reject(response))
      .then((payload) => {
        setPages(payload.pages.length ? payload.pages : cloneDefaults());
        setSettings(payload.settings || defaultSettings);
        setAdmins(payload.admins || []);
      })
      .catch(() => showNotice("پیش‌نمایش محلی فعال است؛ ذخیره آنلاین پس از ورود مدیر در دسترس است."));
  }, [showNotice]);

  const page = useMemo(() => pages.find((item) => item.slug === pageSlug) || pages[0], [pageSlug, pages]);
  const selectedBlock = useMemo(() => page?.blocks.find((item) => item.id === selectedBlockId) || page?.blocks[0], [page, selectedBlockId]);

  const snapshot = useCallback(() => {
    history.current.push(jsonClone(pages));
    if (history.current.length > 30) history.current.shift();
    setCanUndo(true);
    setSaveState("dirty");
  }, [pages]);

  const patchPage = (changes: Partial<CmsPage>) => {
    snapshot();
    setPages((current) => current.map((item) => item.slug === page.slug ? { ...item, ...changes } : item));
  };

  const patchBlock = (changes: Partial<CmsBlock>) => {
    if (!selectedBlock) return;
    snapshot();
    setPages((current) => current.map((item) => item.slug === page.slug ? { ...item, blocks: item.blocks.map((block) => block.id === selectedBlock.id ? { ...block, ...changes } : block) } : item));
  };

  const choosePage = (slug: string) => {
    setPageSlug(slug);
    const next = pages.find((item) => item.slug === slug);
    setSelectedBlockId(next?.blocks[0]?.id || "");
  };

  const addPage = () => {
    snapshot();
    const slug = `page-${Date.now().toString(36)}`;
    const firstBlock: CmsBlock = { ...jsonClone(blockTemplates.hero), id: `${slug}-hero`, label: "هدر صفحه جدید" };
    const nextPage: CmsPage = { slug, title: "صفحه جدید", menuLabel: "صفحه جدید", description: "توضیح این صفحه را وارد کنید.", status: "draft", blocks: [firstBlock] };
    setPages((current) => [...current, nextPage]);
    setPageSlug(slug);
    setSelectedBlockId(firstBlock.id);
    showNotice("صفحه جدید ساخته شد؛ نام و محتوای آن را ویرایش کنید.");
  };

  const removePage = async () => {
    if (page.slug === "home") return showNotice("صفحه اصلی قابل حذف نیست.");
    if (!window.confirm(`صفحه «${page.menuLabel}» کامل حذف شود؟`)) return;
    try {
      await postAction({ action: "deletePage", slug: page.slug });
      const remaining = pages.filter((item) => item.slug !== page.slug);
      setPages(remaining);
      setPageSlug("home");
      setSelectedBlockId(remaining.find((item) => item.slug === "home")?.blocks[0]?.id || "");
      showNotice("صفحه حذف شد.");
    } catch (error) { showNotice(error instanceof Error ? error.message : "حذف صفحه انجام نشد"); }
  };

  const addBlock = (type: BlockType) => {
    snapshot();
    const nextBlock: CmsBlock = { ...jsonClone(blockTemplates[type]), id: uid(type) };
    setPages((current) => current.map((item) => item.slug === page.slug ? { ...item, blocks: [...item.blocks, nextBlock] } : item));
    setSelectedBlockId(nextBlock.id);
  };

  const moveBlock = (direction: -1 | 1) => {
    if (!selectedBlock) return;
    const index = page.blocks.findIndex((item) => item.id === selectedBlock.id);
    const destination = index + direction;
    if (destination < 0 || destination >= page.blocks.length) return;
    snapshot();
    const next = [...page.blocks];
    [next[index], next[destination]] = [next[destination], next[index]];
    setPages((current) => current.map((item) => item.slug === page.slug ? { ...item, blocks: next } : item));
  };

  const duplicateBlock = () => {
    if (!selectedBlock) return;
    snapshot();
    const copy = { ...jsonClone(selectedBlock), id: uid(selectedBlock.type), label: `${selectedBlock.label} (کپی)` };
    const index = page.blocks.findIndex((item) => item.id === selectedBlock.id);
    const next = [...page.blocks];
    next.splice(index + 1, 0, copy);
    setPages((current) => current.map((item) => item.slug === page.slug ? { ...item, blocks: next } : item));
    setSelectedBlockId(copy.id);
  };

  const removeBlock = () => {
    if (!selectedBlock || page.blocks.length === 1 || !window.confirm("این بخش از صفحه حذف شود؟")) return;
    snapshot();
    const next = page.blocks.filter((item) => item.id !== selectedBlock.id);
    setPages((current) => current.map((item) => item.slug === page.slug ? { ...item, blocks: next } : item));
    setSelectedBlockId(next[0]?.id || "");
  };

  const updateItem = (index: number, key: "title" | "subtitle" | "body" | "image" | "link" | "category" | "origin" | "moq" | "accent", value: string) => {
    if (!selectedBlock) return;
    const items = jsonClone(selectedBlock.items || []);
    items[index] = { ...items[index], [key]: value };
    patchBlock({ items });
  };

  const addItem = () => {
    const items = [...(selectedBlock?.items || []), { title: "آیتم جدید", subtitle: "NEW ITEM", body: "توضیحات آیتم" }];
    patchBlock({ items });
  };

  const removeItem = (index: number) => patchBlock({ items: (selectedBlock?.items || []).filter((_, itemIndex) => itemIndex !== index) });

  const undo = () => {
    const previous = history.current.pop();
    if (!previous) return;
    setPages(previous);
    setCanUndo(history.current.length > 0);
    setSaveState("dirty");
    showNotice("آخرین تغییر برگردانده شد.");
  };

  const postAction = async (body: Record<string, unknown>): Promise<ApiResult> => {
    const response = await fetch("/api/admin/cms", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
    const result = await response.json().catch(() => ({})) as ApiResult;
    if (!response.ok) throw new Error(result.error || "ذخیره انجام نشد");
    return result;
  };

  const savePage = async () => {
    setSaveState("saving");
    try {
      await postAction({ action: "savePage", page });
      setSaveState("saved");
      showNotice("صفحه و نسخه جدید با موفقیت ذخیره شد.");
    } catch (error) {
      setSaveState("dirty");
      showNotice(error instanceof Error ? error.message : "خطا در ذخیره");
    }
  };

  const saveSettings = async () => {
    try {
      await postAction({ action: "saveSettings", settings });
      showNotice("تنظیمات سایت ذخیره شد.");
    } catch (error) { showNotice(error instanceof Error ? error.message : "خطا در ذخیره"); }
  };

  const addAdmin = async () => {
    if (!/^\S+@\S+\.\S+$/.test(adminEmail)) return showNotice("یک ایمیل معتبر وارد کنید.");
    try {
      const result = await postAction({ action: "addAdmin", email: adminEmail, role: adminRole });
      setAdmins(result.admins || []);
      setAdminEmail("");
      showNotice("مدیر جدید اضافه شد.");
    } catch (error) { showNotice(error instanceof Error ? error.message : "خطا در افزودن مدیر"); }
  };

  const updateAdmin = async (id: string, role: AdminRecord["role"]) => {
    try {
      const result = await postAction({ action: "updateAdmin", id, role });
      setAdmins(result.admins || []);
      showNotice("سطح دسترسی به‌روزرسانی شد.");
    } catch (error) { showNotice(error instanceof Error ? error.message : "خطا در تغییر دسترسی"); }
  };

  const removeAdmin = async (id: string) => {
    if (!window.confirm("دسترسی این مدیر حذف شود؟")) return;
    try {
      const result = await postAction({ action: "removeAdmin", id });
      setAdmins(result.admins || []);
      showNotice("دسترسی مدیر حذف شد.");
    } catch (error) { showNotice(error instanceof Error ? error.message : "خطا در حذف مدیر"); }
  };

  const uploadFile = async (file?: File) => {
    if (!file) return;
    setUploading(true);
    const data = new FormData();
    data.append("file", file);
    try {
      const response = await fetch("/api/admin/uploads", { method: "POST", body: data });
      const result = await response.json() as ApiResult;
      if (!response.ok) throw new Error(result.error || "آپلود انجام نشد");
      if (selectedBlock) {
        if (String(result.mime || "").startsWith("video/") || selectedBlock.type === "video") patchBlock({ videoUrl: String(result.url || "") });
        else patchBlock({ image: String(result.url || "") });
      }
      showNotice(String(result.mime || "").startsWith("video/") ? "ویدیو بارگذاری و متصل شد." : "تصویر بارگذاری و به بخش انتخاب‌شده متصل شد.");
    } catch (error) { showNotice(error instanceof Error ? error.message : "خطا در آپلود"); }
    finally { setUploading(false); if (fileInput.current) fileInput.current.value = ""; }
  };

  return (
    <div className="studio" dir="rtl">
      <aside className="studio-sidebar">
        <a className="studio-brand" href="/" target="_blank"><span>Z</span><div><b>ZAGROS</b><small>CONTENT STUDIO</small></div></a>
        <div className="studio-site-status"><i /><div><b>سایت آنلاین</b><small>همه سیستم‌ها فعال</small></div></div>
        <nav>
          {(Object.keys(viewLabels) as StudioView[]).map((key, index) => <button className={view === key ? "active" : ""} key={key} onClick={() => setView(key)}><span>{["⌂", "✦", "♙", "▧", "⚙"][index]}</span><b>{viewLabels[key]}</b><small>0{index + 1}</small></button>)}
        </nav>
        <div className="studio-user"><span>{currentUser.displayName.slice(0, 1).toUpperCase()}</span><div><b>{currentUser.displayName}</b><small>{currentUser.email}</small></div><Link href="/cdn-cgi/access/logout">↗</Link></div>
      </aside>

      <main className="studio-main">
        <header className="studio-topbar">
          <div><small>ZAGROS / MANAGEMENT</small><b>{viewLabels[view]}</b></div>
          <label className="studio-search">⌕<input placeholder="جست‌وجو در صفحات و محتوا..." /></label>
          <div className="studio-top-actions"><span className={`studio-save-state ${saveState}`}>{saveState === "saved" ? "همه تغییرات ذخیره شده" : saveState === "saving" ? "در حال ذخیره..." : "تغییر ذخیره‌نشده"}</span><a href="/" target="_blank">مشاهده سایت ↖</a></div>
        </header>

        <div className="studio-content">
          {view === "overview" && <Overview pages={pages} admins={admins} onOpenBuilder={() => setView("builder")} />}
          {view === "builder" && <div className="builder-shell">
            <section className="builder-edit">
              <header className="studio-page-head"><div><small>FULL SITE EDITOR</small><h1>ویرایش کامل سایت</h1><p>هر بخش را انتخاب کنید؛ تغییرات همان لحظه در پیش‌نمایش دیده می‌شود.</p></div><div className="builder-head-actions"><button onClick={undo} disabled={!canUndo}>↶ بازگشت</button><button className="primary" onClick={savePage}>ذخیره صفحه</button></div></header>

              <div className="page-tabs">{pages.map((item) => <button className={item.slug === page.slug ? "active" : ""} onClick={() => choosePage(item.slug)} key={item.slug}><span>{item.menuLabel}</span><small>{item.status === "published" ? "منتشر" : "پیش‌نویس"}</small></button>)}<button className="page-add" onClick={addPage}><span>＋ صفحه جدید</span><small>افزودن به منو</small></button></div>

              <section className="page-meta-card">
                <div className="field-row"><label className="studio-field"><span>نام صفحه</span><input value={page.title} onChange={(event) => patchPage({ title: event.target.value })} /></label><label className="studio-field"><span>عنوان منو</span><input value={page.menuLabel} onChange={(event) => patchPage({ menuLabel: event.target.value })} /></label></div>
                <label className="studio-field"><span>توضیح برای موتور جست‌وجو</span><input value={page.description} onChange={(event) => patchPage({ description: event.target.value })} /></label>
                <div className="page-publish-row"><label className="publish-switch"><input type="checkbox" checked={page.status === "published"} onChange={(event) => patchPage({ status: event.target.checked ? "published" : "draft" })} /><i /><span>نمایش این صفحه در سایت</span></label>{page.slug !== "home" && <button className="delete-page" onClick={removePage}>حذف کامل صفحه</button>}</div>
              </section>

              <div className="block-builder">
                <aside className="block-list"><header><div><b>ساختار صفحه</b><small>{page.blocks.length.toLocaleString("fa-IR")} بخش</small></div><span>برای ویرایش انتخاب کنید</span></header>{page.blocks.map((block, index) => <button className={selectedBlock?.id === block.id ? "active" : ""} key={block.id} onClick={() => setSelectedBlockId(block.id)}><i>{blockIcon[block.type]}</i><span><b>{block.label}</b><small>{blockLabels[block.type]} · {String(index + 1).padStart(2, "0")}</small></span><em className={block.visible ? "live" : "hidden"}>{block.visible ? "●" : "○"}</em></button>)}<details className="add-block"><summary>+ افزودن بخش جدید</summary><div>{(Object.keys(blockLabels) as BlockType[]).map((type) => <button onClick={() => addBlock(type)} key={type}><i>{blockIcon[type]}</i>{blockLabels[type]}</button>)}</div></details></aside>
                {selectedBlock && <section className="block-editor">
                  <header><div><small>{selectedBlock.type.toUpperCase()} SECTION</small><input value={selectedBlock.label} onChange={(event) => patchBlock({ label: event.target.value })} aria-label="نام داخلی بخش" /></div><div className="block-tools"><button onClick={() => moveBlock(-1)} title="انتقال به بالا">↑</button><button onClick={() => moveBlock(1)} title="انتقال به پایین">↓</button><button onClick={duplicateBlock} title="تکثیر">⧉</button><button className="danger" onClick={removeBlock} title="حذف">⌫</button></div></header>
                  <div className="block-visibility"><label><input type="checkbox" checked={selectedBlock.visible} onChange={(event) => patchBlock({ visible: event.target.checked })} /><i /><span>بخش در سایت نمایش داده شود</span></label><label className="tone-select"><span>پس‌زمینه</span><select value={selectedBlock.tone || "light"} onChange={(event) => patchBlock({ tone: event.target.value as CmsBlock["tone"] })}><option value="light">سفید</option><option value="soft">کرم روشن</option><option value="brand">سبز برند</option></select></label></div>
                  <div className="field-row"><label className="studio-field"><span>بالانویس</span><input value={selectedBlock.eyebrow || ""} onChange={(event) => patchBlock({ eyebrow: event.target.value })} placeholder="مثال: GLOBAL SOURCING" /></label><label className="studio-field"><span>عنوان</span><input value={selectedBlock.title || ""} onChange={(event) => patchBlock({ title: event.target.value })} /></label></div>
                  {selectedBlock.type === "hero" && <label className="studio-field"><span>بخش برجسته عنوان</span><input value={selectedBlock.accent || ""} onChange={(event) => patchBlock({ accent: event.target.value })} /></label>}
                  {!["stats", "table"].includes(selectedBlock.type) && <label className="studio-field"><span>متن توضیح</span><textarea rows={4} value={selectedBlock.body || ""} onChange={(event) => patchBlock({ body: event.target.value })} /></label>}
                  {["hero", "image", "video"].includes(selectedBlock.type) && <div className="image-field"><div><img src={selectedBlock.image || "/isfahan.webp"} alt="" /></div><label className="studio-field"><span>{selectedBlock.type === "video" ? "پوستر ویدیو" : "آدرس تصویر"}</span><input dir="ltr" value={selectedBlock.image || ""} onChange={(event) => patchBlock({ image: event.target.value })} /></label><button onClick={() => fileInput.current?.click()}>{uploading ? "در حال بارگذاری..." : selectedBlock.type === "video" ? "بارگذاری ویدیو" : "جایگزینی تصویر"}</button></div>}
                  {selectedBlock.type === "video" && <div className="video-editor"><label className="studio-field"><span>آدرس فایل ویدیو یا MP4</span><input dir="ltr" value={selectedBlock.videoUrl || ""} onChange={(event) => patchBlock({ videoUrl: event.target.value })} placeholder="https://.../brand-film.mp4" /></label><div className="video-options"><label><input type="checkbox" checked={selectedBlock.autoplay || false} onChange={(event) => patchBlock({ autoplay: event.target.checked })} /> پخش خودکار</label><label><input type="checkbox" checked={selectedBlock.muted ?? true} onChange={(event) => patchBlock({ muted: event.target.checked })} /> بی‌صدا</label><label><input type="checkbox" checked={selectedBlock.loop || false} onChange={(event) => patchBlock({ loop: event.target.checked })} /> تکرار</label></div></div>}
                  {["hero", "cta"].includes(selectedBlock.type) && <div className="field-row"><label className="studio-field"><span>متن دکمه</span><input value={selectedBlock.buttonText || ""} onChange={(event) => patchBlock({ buttonText: event.target.value })} /></label><label className="studio-field"><span>لینک دکمه</span><input dir="ltr" value={selectedBlock.buttonLink || ""} onChange={(event) => patchBlock({ buttonLink: event.target.value })} /></label></div>}
                  {["cards", "stats", "gallery", "faq"].includes(selectedBlock.type) && <div className="items-editor"><header><div><b>{selectedBlock.type === "stats" ? "شاخص‌ها" : selectedBlock.type === "gallery" ? "تصاویر گالری" : selectedBlock.type === "faq" ? "پرسش و پاسخ‌ها" : "کارت‌ها و سطرها"}</b><small>هر آیتم را جداگانه ویرایش کنید.</small></div><button onClick={addItem}>+ افزودن آیتم</button></header>{(selectedBlock.items || []).map((item, index) => <article key={index}><div className="item-number">{String(index + 1).padStart(2, "0")}</div><div className="item-fields"><div className="field-row"><label className="studio-field"><span>{selectedBlock.type === "faq" ? "پرسش" : "عنوان"}</span><input value={item.title} onChange={(event) => updateItem(index, "title", event.target.value)} /></label>{!["gallery", "faq"].includes(selectedBlock.type) && <label className="studio-field"><span>برچسب / زیرعنوان</span><input value={item.subtitle || ""} onChange={(event) => updateItem(index, "subtitle", event.target.value)} /></label>}</div>{["cards", "faq"].includes(selectedBlock.type) && <label className="studio-field"><span>{selectedBlock.type === "faq" ? "پاسخ" : "توضیح"}</span><textarea rows={2} value={item.body || ""} onChange={(event) => updateItem(index, "body", event.target.value)} /></label>}{selectedBlock.type === "cards" && <div className="product-meta-editor"><div className="field-row"><label className="studio-field"><span>دسته‌بندی</span><input value={item.category || ""} onChange={(event) => updateItem(index, "category", event.target.value)} placeholder="قهوه سبز / ادویه‌جات / خشکبار" /></label><label className="studio-field"><span>مبدأ</span><input value={item.origin || ""} onChange={(event) => updateItem(index, "origin", event.target.value)} /></label></div><div className="field-row"><label className="studio-field"><span>حداقل سفارش</span><input value={item.moq || ""} onChange={(event) => updateItem(index, "moq", event.target.value)} /></label><label className="studio-field"><span>رنگ تأکیدی</span><input dir="ltr" value={item.accent || ""} onChange={(event) => updateItem(index, "accent", event.target.value)} placeholder="#d88b32" /></label></div></div>}{["cards", "gallery"].includes(selectedBlock.type) && <div className="field-row"><label className="studio-field"><span>تصویر</span><input dir="ltr" value={item.image || ""} onChange={(event) => updateItem(index, "image", event.target.value)} /></label>{selectedBlock.type === "cards" && <label className="studio-field"><span>لینک (اختیاری)</span><input dir="ltr" value={item.link || ""} onChange={(event) => updateItem(index, "link", event.target.value)} /></label>}</div>}</div><button className="item-remove" onClick={() => removeItem(index)}>×</button></article>)}</div>}
                  {selectedBlock.type === "table" && <div className="table-editor"><label className="studio-field"><span>نام ستون‌ها — با علامت | جدا کنید</span><input value={(selectedBlock.columns || []).join(" | ")} onChange={(event) => patchBlock({ columns: event.target.value.split("|").map((cell) => cell.trim()) })} /></label><label className="studio-field"><span>سطرهای جدول — هر سطر یک خط، خانه‌ها با |</span><textarea rows={7} value={(selectedBlock.rows || []).map((row) => row.join(" | ")).join("\n")} onChange={(event) => patchBlock({ rows: event.target.value.split("\n").map((row) => row.split("|").map((cell) => cell.trim())) })} /></label><button onClick={() => patchBlock({ rows: [...(selectedBlock.rows || []), (selectedBlock.columns || []).map(() => "مقدار جدید")] })}>+ افزودن سطر جدول</button></div>}
                </section>}
              </div>
            </section>

            <aside className={`studio-preview studio-preview--${previewMode}`}>
              <header><div><i /><span>پیش‌نمایش زنده</span></div><div><button className={previewMode === "desktop" ? "active" : ""} onClick={() => setPreviewMode("desktop")}>▱</button><button className={previewMode === "mobile" ? "active" : ""} onClick={() => setPreviewMode("mobile")}>▯</button><a href={page.slug === "home" ? "/" : `/${page.slug}`} target="_blank">↖</a></div></header>
              <div className="studio-preview__viewport"><div className="studio-preview__canvas"><PublicSite previewPage={page} slug={page.slug} /></div></div>
              <footer><span>{page.menuLabel}</span><b>{page.blocks.filter((block) => block.visible).length.toLocaleString("fa-IR")} بخش فعال</b></footer>
            </aside>
          </div>}
          {view === "admins" && <AdminsView admins={admins} email={adminEmail} role={adminRole} setEmail={setAdminEmail} setRole={setAdminRole} addAdmin={addAdmin} updateAdmin={updateAdmin} removeAdmin={removeAdmin} currentEmail={currentUser.email} />}
          {view === "media" && <MediaView fileInput={fileInput} uploadFile={uploadFile} uploading={uploading} onUseHero={() => { setView("builder"); choosePage("home"); setSelectedBlockId("home-hero"); }} />}
          {view === "settings" && <SettingsView settings={settings} setSettings={setSettings} save={saveSettings} />}
        </div>
      </main>
      <input ref={fileInput} type="file" accept="image/png,image/jpeg,image/webp,video/mp4,video/webm" hidden onChange={(event) => uploadFile(event.target.files?.[0])} />
      <div className={`studio-toast ${notice ? "show" : ""}`}><i>✓</i>{notice}</div>
    </div>
  );
}

function Overview({ pages, admins, onOpenBuilder }: { pages: CmsPage[]; admins: AdminRecord[]; onOpenBuilder: () => void }) {
  const blocks = pages.reduce((sum, page) => sum + page.blocks.length, 0);
  return <div className="overview"><header className="studio-page-head"><div><small>COMMAND CENTER / OVERVIEW</small><h1>سلام، مدیریت زاگرس</h1><p>وضعیت محتوا، صفحات و دسترسی مدیران در یک نگاه.</p></div><button className="primary" onClick={onOpenBuilder}>شروع ویرایش سایت ←</button></header><div className="overview-metrics"><article><span>صفحات سایت</span><strong>{pages.length.toLocaleString("fa-IR")}</strong><small>{pages.filter((page) => page.status === "published").length.toLocaleString("fa-IR")} صفحه منتشر</small><i style={{ width: "88%" }} /></article><article><span>بخش‌های قابل ویرایش</span><strong>{blocks.toLocaleString("fa-IR")}</strong><small>متن، عکس، ویدیو، گالری، کارت و جدول</small><i style={{ width: "76%" }} /></article><article><span>مدیران فعال</span><strong>{admins.length.toLocaleString("fa-IR")}</strong><small>با دسترسی مبتنی بر ایمیل</small><i style={{ width: "62%" }} /></article><article className="accent"><span>سلامت محتوا</span><strong>۹۴٪</strong><small>آماده انتشار و به‌روزرسانی</small><i style={{ width: "94%" }} /></article></div><div className="overview-grid"><section className="overview-panel"><header><div><small>SITE STRUCTURE</small><h2>همه صفحات</h2></div><button onClick={onOpenBuilder}>ویرایش ←</button></header>{pages.map((page) => <div className="overview-page" key={page.slug}><span>{page.menuLabel.slice(0, 1)}</span><div><b>{page.menuLabel}</b><small>{page.blocks.length.toLocaleString("fa-IR")} بخش قابل ویرایش</small></div><em>{page.status === "published" ? "منتشر" : "پیش‌نویس"}</em></div>)}</section><section className="overview-panel overview-activity"><header><div><small>LATEST ACTIVITY</small><h2>فعالیت‌های اخیر</h2></div></header><article><i /><div><b>ورود سینمایی برند فعال شد</b><span>موشن اختصاصی زاگرس پیش از ورود به سایت</span></div><time>اکنون</time></article><article><i /><div><b>ساختار ویرایش همه صفحات</b><span>بخش‌های انعطاف‌پذیر اضافه شدند</span></div><time>امروز</time></article><article><i /><div><b>مدیریت دسترسی</b><span>نقش مدیر و ویرایشگر فعال شد</span></div><time>امروز</time></article></section></div></div>;
}

function AdminsView({ admins, email, role, setEmail, setRole, addAdmin, updateAdmin, removeAdmin, currentEmail }: { admins: AdminRecord[]; email: string; role: AdminRecord["role"]; setEmail: (value: string) => void; setRole: (value: AdminRecord["role"]) => void; addAdmin: () => void; updateAdmin: (id: string, role: AdminRecord["role"]) => void; removeAdmin: (id: string) => void; currentEmail: string }) {
  return <div className="admin-access"><header className="studio-page-head"><div><small>ACCESS CONTROL / ADMINS</small><h1>مدیران و سطح دسترسی</h1><p>هر مدیر با ایمیل خود وارد می‌شود و فقط امکانات مجاز را می‌بیند.</p></div></header><section className="invite-card"><div><span>+</span><div><h2>افزودن مدیر جدید</h2><p>ایمیل و نقش همکار را وارد کنید. پس از ورود با همان ایمیل، دسترسی فعال است.</p></div></div><div className="invite-form"><label className="studio-field"><span>ایمیل مدیر</span><input dir="ltr" type="email" placeholder="name@company.com" value={email} onChange={(event) => setEmail(event.target.value)} /></label><label className="studio-field"><span>سطح دسترسی</span><select value={role} onChange={(event) => setRole(event.target.value as AdminRecord["role"])}><option value="admin">مدیر کامل</option><option value="editor">ویرایشگر محتوا</option><option value="viewer">فقط مشاهده</option></select></label><button onClick={addAdmin}>افزودن مدیر</button></div></section><section className="admin-list"><header><div><b>اعضای دارای دسترسی</b><small>{admins.length.toLocaleString("fa-IR")} مدیر ثبت‌شده</small></div><span>ورود امن با حساب کاربری</span></header>{admins.length ? admins.map((admin) => <article key={admin.id}><span className="admin-avatar">{(admin.name || admin.email).slice(0, 1).toUpperCase()}</span><div className="admin-identity"><b>{admin.name || "مدیر زاگرس"}{admin.email === currentEmail && <em>شما</em>}</b><small dir="ltr">{admin.email}</small></div><span className={`admin-status ${admin.status}`}>● {admin.status === "active" ? "فعال" : "در انتظار ورود"}</span><select value={admin.role} disabled={admin.role === "owner"} onChange={(event) => updateAdmin(admin.id, event.target.value as AdminRecord["role"])}><option value="owner">مالک</option><option value="admin">مدیر کامل</option><option value="editor">ویرایشگر</option><option value="viewer">مشاهده‌گر</option></select><button className="admin-remove" disabled={admin.role === "owner" || admin.email === currentEmail} onClick={() => removeAdmin(admin.id)}>حذف</button></article>) : <div className="empty-state">هنوز مدیری ثبت نشده است.</div>}</section><div className="permission-grid"><article><b>مالک</b><p>همه امکانات، مدیریت مدیران و تنظیمات حساس.</p></article><article><b>مدیر کامل</b><p>ویرایش همه صفحات، رسانه و انتشار محتوا.</p></article><article><b>ویرایشگر</b><p>ساخت و ویرایش محتوا بدون مدیریت دسترسی‌ها.</p></article><article><b>مشاهده‌گر</b><p>مشاهده پنل و پیش‌نمایش بدون امکان ذخیره.</p></article></div></div>;
}

function MediaView({ fileInput, uploadFile, uploading, onUseHero }: { fileInput: React.RefObject<HTMLInputElement | null>; uploadFile: (file?: File) => void; uploading: boolean; onUseHero: () => void }) {
  const media = [{ src: "/zagros-holding-hero-v2.png", title: "تصویر اصلی هلدینگ", meta: "HERO · NEW" }, { src: "/coffee.webp", title: "قهوه سبز", meta: "PRODUCT" }, { src: "/spices.webp", title: "ادویه‌جات", meta: "PRODUCT" }, { src: "/nuts.webp", title: "خشکبار", meta: "PRODUCT" }];
  return <div className="media-view"><header className="studio-page-head"><div><small>MEDIA LIBRARY / ASSETS</small><h1>کتابخانه تصویر و ویدیو</h1><p>عکس یا ویدیو را بارگذاری کنید و در هر بخش از سایت استفاده کنید.</p></div><button className="primary" onClick={() => fileInput.current?.click()}>{uploading ? "در حال بارگذاری..." : "+ بارگذاری رسانه"}</button></header><div className="upload-zone" onClick={() => fileInput.current?.click()} onDragOver={(event) => event.preventDefault()} onDrop={(event) => { event.preventDefault(); uploadFile(event.dataTransfer.files[0]); }}><span>⇧</span><b>عکس یا ویدیو را اینجا رها کنید</b><p>PNG، JPG و WEBP تا ۸ مگابایت · MP4 و WEBM تا ۸۰ مگابایت</p></div><div className="media-grid">{media.map((item, index) => <article key={item.src}><div><img src={item.src} alt={item.title} /><span>{index === 0 ? "تصویر جدید" : "فعال"}</span></div><section><h3>{item.title}</h3><p>{item.meta}</p><button onClick={index === 0 ? onUseHero : undefined}>استفاده در صفحه</button></section></article>)}</div></div>;
}

function SettingsView({ settings, setSettings, save }: { settings: CmsSettings; setSettings: (value: CmsSettings) => void; save: () => void }) {
  const field = (key: keyof CmsSettings, value: string | number | boolean) => setSettings({ ...settings, [key]: value });
  return <div className="settings-view"><header className="studio-page-head"><div><small>SITE / GLOBAL SETTINGS</small><h1>تنظیمات عمومی سایت</h1><p>برند، ورود موشن، اطلاعات تماس و اجزای مشترک همه صفحات.</p></div><button className="primary" onClick={save}>ذخیره تنظیمات</button></header><div className="settings-grid"><section><header><small>BRAND IDENTITY</small><h2>نام و هویت برند</h2></header><div className="field-row"><label className="studio-field"><span>نام برند</span><input dir="ltr" value={settings.brandName} onChange={(event) => field("brandName", event.target.value)} /></label><label className="studio-field"><span>توضیح برند</span><input dir="ltr" value={settings.brandDescriptor} onChange={(event) => field("brandDescriptor", event.target.value)} /></label></div><label className="studio-field"><span>متن فوتر</span><textarea rows={3} value={settings.footerLine} onChange={(event) => field("footerLine", event.target.value)} /></label></section><section><header><small>TRADE DESK</small><h2>اطلاعات تماس</h2></header><label className="studio-field"><span>ایمیل تجاری</span><input dir="ltr" value={settings.email} onChange={(event) => field("email", event.target.value)} /></label><div className="field-row"><label className="studio-field"><span>تلفن</span><input dir="ltr" value={settings.phone} onChange={(event) => field("phone", event.target.value)} /></label><label className="studio-field"><span>واتساپ</span><input dir="ltr" value={settings.whatsapp} onChange={(event) => field("whatsapp", event.target.value)} /></label></div><label className="studio-field"><span>آدرس</span><input value={settings.location} onChange={(event) => field("location", event.target.value)} /></label></section><section className="intro-settings"><header><small>BRAND MOTION INTRO</small><h2>ورودی سینمایی سایت</h2></header><label className="publish-switch"><input type="checkbox" checked={settings.introEnabled} onChange={(event) => field("introEnabled", event.target.checked)} /><i /><span>نمایش ورود برندی برای بازدیدکننده</span></label><div className="field-row"><label className="studio-field"><span>عنوان بزرگ</span><input dir="ltr" value={settings.introTitle} onChange={(event) => field("introTitle", event.target.value)} /></label><label className="studio-field"><span>بالانویس</span><input dir="ltr" value={settings.introKicker} onChange={(event) => field("introKicker", event.target.value)} /></label></div><div className="field-row"><label className="studio-field"><span>بخش اول شعار</span><input value={settings.introSubtitle} onChange={(event) => field("introSubtitle", event.target.value)} /></label><label className="studio-field"><span>بخش برجسته شعار</span><input value={settings.introAccent} onChange={(event) => field("introAccent", event.target.value)} /></label></div><label className="studio-field"><span>مدت نمایش — میلی‌ثانیه</span><input dir="ltr" type="number" min="2800" max="10000" value={settings.introDuration} onChange={(event) => field("introDuration", Number(event.target.value))} /></label></section></div></div>;
}
