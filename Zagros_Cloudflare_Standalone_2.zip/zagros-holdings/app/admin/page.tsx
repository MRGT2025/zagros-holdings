import { redirect } from "next/navigation";
import AdminStudio from "../components/AdminStudio";
import { getCloudflareUser } from "../cloudflare-auth";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const user = await getCloudflareUser();
  if (!user) redirect("/");
  return <AdminStudio currentUser={user} />;
}
