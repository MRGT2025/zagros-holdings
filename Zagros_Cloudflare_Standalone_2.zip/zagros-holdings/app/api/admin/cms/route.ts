import type { AdminRecord, CmsPage, CmsSettings } from "../../../lib/cms";
import { canEdit, canManageAdmins, getAdmins, getCmsEnv, getPages, getSettings, requireCmsAdmin } from "../../../lib/server-cms";

function validRole(value: unknown): value is AdminRecord["role"] {
  return value === "owner" || value === "admin" || value === "editor" || value === "viewer";
}

export async function GET(request: Request) {
  try {
    const currentAdmin = await requireCmsAdmin(request);
    const [pages, settings, admins] = await Promise.all([getPages(), getSettings(), getAdmins()]);
    return Response.json({ pages, settings, admins, currentAdmin });
  } catch (error) {
    if (error instanceof Response) return error;
    return Response.json({ error: "امکان بارگذاری پنل مدیریت وجود ندارد." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const admin = await requireCmsAdmin(request);
    const payload = await request.json() as Record<string, unknown>;
    const action = String(payload.action || "");
    const db = getCmsEnv().DB;

    if (action === "savePage") {
      if (!canEdit(admin)) return Response.json({ error: "اجازه ویرایش محتوا ندارید." }, { status: 403 });
      const page = payload.page as CmsPage;
      if (!page?.slug || !Array.isArray(page.blocks)) return Response.json({ error: "اطلاعات صفحه معتبر نیست." }, { status: 400 });
      const current = await db.prepare("SELECT content_json FROM pages WHERE slug = ?").bind(page.slug).first<{ content_json: string }>();
      const now = Date.now();
      const writes = [db.prepare(`INSERT INTO pages (slug, title, menu_label, description, status, content_json, updated_at, updated_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(slug) DO UPDATE SET title = excluded.title, menu_label = excluded.menu_label, description = excluded.description, status = excluded.status, content_json = excluded.content_json, updated_at = excluded.updated_at, updated_by = excluded.updated_by`)
        .bind(page.slug, page.title, page.menuLabel, page.description, page.status, JSON.stringify(page.blocks), now, admin.email)];
      if (current) writes.unshift(db.prepare("INSERT INTO page_revisions (id, page_slug, content_json, created_at, created_by) VALUES (?, ?, ?, ?, ?)").bind(crypto.randomUUID(), page.slug, current.content_json, now, admin.email));
      await db.batch(writes);
      return Response.json({ ok: true, updatedAt: now });
    }

    if (action === "saveSettings") {
      if (!canEdit(admin)) return Response.json({ error: "اجازه تغییر تنظیمات ندارید." }, { status: 403 });
      const settings = payload.settings as CmsSettings;
      await db.prepare("UPDATE site_settings SET value_json = ?, updated_at = ? WHERE setting_key = ?").bind(JSON.stringify(settings), Date.now(), "global").run();
      return Response.json({ ok: true });
    }

    if (action === "deletePage") {
      if (!canEdit(admin)) return Response.json({ error: "اجازه حذف صفحه ندارید." }, { status: 403 });
      const slug = String(payload.slug || "");
      if (!slug || slug === "home") return Response.json({ error: "صفحه اصلی قابل حذف نیست." }, { status: 400 });
      await db.batch([
        db.prepare("DELETE FROM page_revisions WHERE page_slug = ?").bind(slug),
        db.prepare("DELETE FROM pages WHERE slug = ?").bind(slug),
      ]);
      return Response.json({ ok: true });
    }

    if (["addAdmin", "updateAdmin", "removeAdmin"].includes(action) && !canManageAdmins(admin)) return Response.json({ error: "فقط مدیران ارشد می‌توانند دسترسی‌ها را تغییر دهند." }, { status: 403 });

    if (action === "addAdmin") {
      const email = String(payload.email || "").trim().toLowerCase();
      const role = validRole(payload.role) && payload.role !== "owner" ? payload.role : "editor";
      if (!/^\S+@\S+\.\S+$/.test(email)) return Response.json({ error: "ایمیل معتبر نیست." }, { status: 400 });
      await db.prepare(`INSERT INTO admins (id, email, name, role, status, created_at) VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(email) DO UPDATE SET role = excluded.role`)
        .bind(crypto.randomUUID(), email, "", role, "pending", Date.now()).run();
      return Response.json({ admins: await getAdmins() });
    }

    if (action === "updateAdmin") {
      const id = String(payload.id || "");
      if (!validRole(payload.role) || payload.role === "owner") return Response.json({ error: "سطح دسترسی معتبر نیست." }, { status: 400 });
      const target = await db.prepare("SELECT role FROM admins WHERE id = ?").bind(id).first<{ role: string }>();
      if (!target || target.role === "owner") return Response.json({ error: "دسترسی مالک قابل تغییر نیست." }, { status: 400 });
      await db.prepare("UPDATE admins SET role = ? WHERE id = ?").bind(payload.role, id).run();
      return Response.json({ admins: await getAdmins() });
    }

    if (action === "removeAdmin") {
      const id = String(payload.id || "");
      const target = await db.prepare("SELECT email, role FROM admins WHERE id = ?").bind(id).first<{ email: string; role: string }>();
      if (!target || target.role === "owner" || target.email === admin.email) return Response.json({ error: "این مدیر قابل حذف نیست." }, { status: 400 });
      await db.prepare("DELETE FROM admins WHERE id = ?").bind(id).run();
      return Response.json({ admins: await getAdmins() });
    }

    return Response.json({ error: "عملیات ناشناخته است." }, { status: 400 });
  } catch (error) {
    if (error instanceof Response) return error;
    const message = error instanceof Error ? error.message : "خطای ناشناخته";
    return Response.json({ error: message }, { status: 500 });
  }
}
