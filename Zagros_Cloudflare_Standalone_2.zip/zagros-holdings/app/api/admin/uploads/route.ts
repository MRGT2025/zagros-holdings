import { canEdit, getCmsEnv, requireCmsAdmin } from "../../../lib/server-cms";

export async function POST(request: Request) {
  try {
    const admin = await requireCmsAdmin(request);
    if (!canEdit(admin)) return Response.json({ error: "اجازه بارگذاری تصویر ندارید." }, { status: 403 });
    const form = await request.formData();
    const file = form.get("file");
    if (!(file instanceof File)) return Response.json({ error: "فایل تصویر انتخاب نشده است." }, { status: 400 });
    const isImage = /^image\/(png|jpeg|webp)$/.test(file.type);
    const isVideo = /^video\/(mp4|webm)$/.test(file.type);
    const sizeLimit = isVideo ? 80 * 1024 * 1024 : 8 * 1024 * 1024;
    if ((!isImage && !isVideo) || file.size > sizeLimit) return Response.json({ error: "تصویر تا ۸ مگابایت یا ویدیوی MP4/WEBM تا ۸۰ مگابایت مجاز است." }, { status: 400 });
    const extension = file.type === "image/png" ? "png" : file.type === "image/webp" ? "webp" : file.type === "video/mp4" ? "mp4" : file.type === "video/webm" ? "webm" : "jpg";
    const key = `${crypto.randomUUID()}.${extension}`;
    const { BUCKET, DB } = getCmsEnv();
    if (!BUCKET) return Response.json({ error: "فضای ذخیره تصاویر فعال نیست." }, { status: 503 });
    await BUCKET.put(key, file.stream(), { httpMetadata: { contentType: file.type } });
    await DB.prepare("INSERT INTO media (id, object_key, filename, mime_type, size, uploaded_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)")
      .bind(crypto.randomUUID(), key, file.name, file.type, file.size, admin.email, Date.now()).run();
    return Response.json({ url: `/media/${key}`, key, mime: file.type });
  } catch (error) {
    if (error instanceof Response) return error;
    return Response.json({ error: error instanceof Error ? error.message : "بارگذاری انجام نشد." }, { status: 500 });
  }
}
