import { getPages, getSettings } from "../../../lib/server-cms";

export async function GET() {
  try {
    const [pages, settings] = await Promise.all([getPages({ publishedOnly: true }), getSettings()]);
    return Response.json({ pages, settings }, { headers: { "cache-control": "public, max-age=60" } });
  } catch {
    return Response.json({ error: "محتوای سایت موقتاً در دسترس نیست." }, { status: 500 });
  }
}

