export type BlockType =
  | "hero"
  | "text"
  | "stats"
  | "cards"
  | "image"
  | "video"
  | "gallery"
  | "faq"
  | "table"
  | "cta";

export type CmsItem = {
  title: string;
  subtitle?: string;
  body?: string;
  meta?: string;
  image?: string;
  link?: string;
  category?: string;
  origin?: string;
  moq?: string;
  accent?: string;
};

export type CmsBlock = {
  id: string;
  type: BlockType;
  label: string;
  eyebrow?: string;
  title?: string;
  accent?: string;
  body?: string;
  image?: string;
  buttonText?: string;
  buttonLink?: string;
  secondaryText?: string;
  secondaryLink?: string;
  items?: CmsItem[];
  columns?: string[];
  rows?: string[][];
  videoUrl?: string;
  autoplay?: boolean;
  loop?: boolean;
  muted?: boolean;
  visible: boolean;
  tone?: "light" | "soft" | "brand";
};

export type CmsPage = {
  slug: string;
  title: string;
  menuLabel: string;
  description: string;
  status: "published" | "draft";
  blocks: CmsBlock[];
  updatedAt?: number;
};

export type CmsSettings = {
  brandName: string;
  brandDescriptor: string;
  email: string;
  phone: string;
  whatsapp: string;
  location: string;
  footerLine: string;
  introEnabled: boolean;
  introKicker: string;
  introTitle: string;
  introSubtitle: string;
  introAccent: string;
  introDuration: number;
};

export type AdminRecord = {
  id: string;
  email: string;
  name: string;
  role: "owner" | "admin" | "editor" | "viewer";
  status: "active" | "pending";
  createdAt: number;
};

export const defaultSettings: CmsSettings = {
  brandName: "ZAGROS",
  brandDescriptor: "HOLDING",
  email: "trade@zagrosholding.ir",
  phone: "+98 31 0000 0000",
  whatsapp: "989120000000",
  location: "اصفهان، ایران",
  footerLine: "قهوه سبز، ادویه‌جات و خشکبار؛ از تعریف خرید تا هماهنگی تحویل.",
  introEnabled: true,
  introKicker: "ISFAHAN HEADQUARTERS · ORIGIN NETWORK",
  introTitle: "ZAGROS",
  introSubtitle: "از اصفهان،",
  introAccent: "تا قلب زنجیره تأمین.",
  introDuration: 4600,
};

const hero = (slug: string, title: string, accent: string, body: string): CmsBlock => ({
  id: `${slug}-hero`,
  type: "hero",
  label: "هدر اصلی",
  eyebrow: "ZAGROS HOLDING · GLOBAL SOURCING",
  title,
  accent,
  body,
  image: "/isfahan.webp",
  buttonText: "درخواست تأمین",
  buttonLink: "/contact",
  secondaryText: "مشاهده محصولات",
  secondaryLink: "/products",
  visible: true,
  tone: "brand",
});

export const defaultPages: CmsPage[] = [
  {
    slug: "home",
    title: "صفحه اصلی",
    menuLabel: "خانه",
    description: "معرفی هلدینگ زاگرس و حوزه‌های اصلی فعالیت",
    status: "published",
    blocks: [
      {
        ...hero(
          "home",
          "ریشه در زاگرس،",
          "متصل به جهان.",
          "هلدینگ زاگرس در اصفهان، شریک تخصصی زنجیره تأمین قهوه سبز، ادویه‌جات و خشکبار؛ با انتخاب دقیق مبدأ، کنترل مستمر کیفیت و پاسخ‌گویی روشن به بازار ایران.",
        ),
        buttonText: "ورود به فروشگاه",
        buttonLink: "/shop",
        secondaryText: "مشاهده شبکه تأمین",
        secondaryLink: "/network",
      },
      {
        id: "home-stats",
        type: "stats",
        label: "آمار کلیدی",
        eyebrow: "ZAGROS AT A GLANCE",
        items: [
          { title: "۶+", subtitle: "مسیر منتخب مبدأ" },
          { title: "۳", subtitle: "گروه کالایی تخصصی" },
          { title: "B2B", subtitle: "فروش عمده و کانتینری" },
          { title: "ISFAHAN", subtitle: "مرکز تصمیم‌گیری" },
        ],
        visible: true,
        tone: "soft",
      },
      {
        id: "home-categories",
        type: "cards",
        label: "حوزه‌های فعالیت",
        eyebrow: "OUR BUSINESS PORTFOLIO",
        title: "سه بازار تخصصی، یک شبکه منسجم",
        body: "هر سفارش بر اساس کاربرد، گرید، مبدأ، حجم و شرایط تحویل تعریف می‌شود.",
        items: [
          { title: "قهوه سبز", subtitle: "GREEN COFFEE", body: "عربیکا و روبوستا برای رستری‌ها و تولیدکنندگان.", image: "/coffee.webp", link: "/products" },
          { title: "ادویه‌جات", subtitle: "SPICES", body: "هل، فلفل و زردچوبه با تعریف دقیق گرید.", image: "/spices.webp", link: "/products" },
          { title: "خشکبار", subtitle: "NUTS", body: "محصولات منتخب برای بازار حرفه‌ای و عمده.", image: "/nuts.webp", link: "/products" },
        ],
        visible: true,
        tone: "light",
      },
      {
        id: "home-process",
        type: "cards",
        label: "فرآیند همکاری",
        eyebrow: "ONE CONNECTED SYSTEM",
        title: "از شرح خرید تا تحویل",
        body: "یک پرونده مشترک، همه تصمیم‌ها و وضعیت محموله را شفاف نگه می‌دارد.",
        items: [
          { title: "تعریف دقیق خرید", subtitle: "01 · MARKET BRIEF", body: "کاربرد، حجم، بودجه و مقصد به یک درخواست قابل اقدام تبدیل می‌شود." },
          { title: "انتخاب مبدأ", subtitle: "02 · ORIGIN OPTIONS", body: "فصل، ظرفیت و تناسب محصول در مسیرهای منتخب مقایسه می‌شود." },
          { title: "نمونه و مشخصات", subtitle: "03 · CONTROL FILE", body: "گرید، نمونه، بسته‌بندی و اسناد پیش از تعهد روشن می‌ماند." },
          { title: "حرکت تا تحویل", subtitle: "04 · DELIVERY VIEW", body: "رزرو، اسناد و وضعیت مسیر در یک نمای پیوسته دنبال می‌شود." },
        ],
        visible: true,
        tone: "brand",
      },
      {
        id: "home-holding-view",
        type: "image",
        label: "نمای هلدینگ و تجارت",
        eyebrow: "ISFAHAN · ORIGIN · LOGISTICS",
        title: "از مبدأ تا بازار، یک تصویر کامل از تجارت.",
        body: "قهوه سبز، ادویه‌جات و خشکبار در کنار کنترل کیفیت، لجستیک و مدیریت اسناد؛ همه در یک زنجیره متصل از اصفهان تا مبدأ.",
        image: "/zagros-holding-hero-v2.png",
        visible: true,
        tone: "light",
      },
      {
        id: "home-cta",
        type: "cta",
        label: "دعوت به اقدام",
        eyebrow: "START A SOURCING FILE",
        title: "برای خرید بعدی، از یک شرح روشن شروع کنیم.",
        body: "محصول، حجم، مقصد و زمان تقریبی تحویل را برای ما بفرستید.",
        buttonText: "ثبت درخواست تأمین",
        buttonLink: "/contact",
        visible: true,
        tone: "soft",
      },
    ],
  },
  {
    slug: "products",
    title: "محصولات",
    menuLabel: "محصولات",
    description: "سبد تخصصی کالاهای هلدینگ زاگرس",
    status: "published",
    blocks: [
      hero("products", "محصولات منتخب،", "برای خرید حرفه‌ای.", "سبد محصول با تمرکز بر نیاز خریداران عمده، گرید مشخص و مسیر تأمین قابل پیگیری."),
      {
        id: "products-grid",
        type: "cards",
        label: "لیست محصولات",
        eyebrow: "SELECTED COMMODITIES",
        title: "سبد تأمین زاگرس",
        body: "مشخصات نهایی هر پیشنهاد بر اساس فصل، حجم و مقصد تأیید می‌شود.",
        items: [
          { title: "عربیکا سانتوس ۱۷/۱۸", subtitle: "BRAZIL SANTOS 17/18", body: "بدنه متعادل برای بلِندهای تجاری و رُست مدیوم.", image: "/coffee.webp", category: "قهوه سبز", origin: "برزیل", moq: "کانتینری", accent: "#73956c" },
          { title: "روبوستا اسکرین ۱۸", subtitle: "VIETNAM ROBUSTA S18", body: "کرمای بالا و ساختار مناسب برای بلِندهای اسپرسو.", image: "/coffee.webp", category: "قهوه سبز", origin: "ویتنام", moq: "کانتینری", accent: "#567a5b" },
          { title: "روبوستا اوگاندا", subtitle: "UGANDA ROBUSTA S18", body: "گزینه‌ای حرفه‌ای برای قدرت، بافت و کرمای فنجان.", image: "/coffee.webp", category: "قهوه سبز", origin: "اوگاندا", moq: "عمده / کانتینری", accent: "#8a7655" },
          { title: "هل سبز", subtitle: "GREEN CARDAMOM", body: "انتخاب گرید براساس رنگ، سایز و شدت رایحه.", image: "/spices.webp", category: "ادویه‌جات", origin: "هند", moq: "عمده", accent: "#709467" },
          { title: "فلفل سیاه", subtitle: "BLACK PEPPER", body: "تعریف محصول براساس دانسیته، رطوبت و تمیزی.", image: "/spices.webp", category: "ادویه‌جات", origin: "هند / ویتنام", moq: "عمده", accent: "#49534d" },
          { title: "زردچوبه", subtitle: "TURMERIC", body: "عرضه برای صنایع غذایی و خطوط بسته‌بندی عمده.", image: "/spices.webp", category: "ادویه‌جات", origin: "هند", moq: "عمده", accent: "#d19b42" },
          { title: "بادام هندی", subtitle: "CASHEW KERNELS", body: "گریدهای منتخب با تعریف شکستگی و بسته‌بندی.", image: "/nuts.webp", category: "خشکبار", origin: "هند / ویتنام", moq: "عمده", accent: "#c49a69" },
          { title: "مغز بادام", subtitle: "ALMOND KERNELS", body: "گزینه‌های مناسب بازار عمده، پخش و فرآوری.", image: "/nuts.webp", category: "خشکبار", origin: "قابل بررسی", moq: "عمده", accent: "#a9835b" },
          { title: "مغز گردو", subtitle: "WALNUT KERNELS", body: "انتخاب براساس رنگ، سایز و درصد شکستگی.", image: "/nuts.webp", category: "خشکبار", origin: "قابل بررسی", moq: "عمده", accent: "#936c43" },
        ],
        visible: true,
        tone: "light",
      },
      {
        id: "products-table",
        type: "table",
        label: "جدول شرایط",
        eyebrow: "TRADE TERMS",
        title: "اطلاعات اولیه سفارش",
        body: "این جدول را می‌توانید از پنل مدیریت، سطر به سطر ویرایش کنید.",
        columns: ["گروه", "مدل تأمین", "حداقل سفارش", "کنترل"],
        rows: [
          ["قهوه سبز", "موجودی / رزرو مبدأ", "کانتینری", "نمونه و مشخصات"],
          ["ادویه‌جات", "سفارش عمده", "طبق محصول", "گرید و بسته‌بندی"],
          ["خشکبار", "سفارش عمده", "طبق محصول", "کیفیت و سایز"],
        ],
        visible: true,
        tone: "soft",
      },
    ],
  },
  {
    slug: "shop",
    title: "فروشگاه استعلام",
    menuLabel: "فروشگاه",
    description: "ساخت سبد استعلام قیمت برای خرید عمده محصولات زاگرس",
    status: "published",
    blocks: [
      hero("shop", "فروشگاه بدون قیمت ثابت؛", "با پیشنهاد متناسب.", "محصولات را به سبد استعلام اضافه کنید. قیمت نهایی براساس حجم، گرید، مبدأ و شرایط تحویل بررسی می‌شود."),
      {
        id: "shop-products",
        type: "cards",
        label: "محصولات فروشگاه",
        eyebrow: "WHOLESALE QUOTE STORE",
        title: "۹ محصول منتخب برای استعلام",
        body: "سبد خود را بسازید و فهرست کامل را یک‌جا برای میز بازرگانی ارسال کنید.",
        items: [
          { title: "عربیکا سانتوس ۱۷/۱۸", subtitle: "BRAZIL SANTOS 17/18", body: "بدنه متعادل برای بلِندهای تجاری و رُست مدیوم.", image: "/coffee.webp", category: "قهوه سبز", origin: "برزیل", moq: "کانتینری", accent: "#73956c" },
          { title: "روبوستا اسکرین ۱۸", subtitle: "VIETNAM ROBUSTA S18", body: "کرمای بالا و ساختار مناسب برای بلِندهای اسپرسو.", image: "/coffee.webp", category: "قهوه سبز", origin: "ویتنام", moq: "کانتینری", accent: "#567a5b" },
          { title: "روبوستا اوگاندا", subtitle: "UGANDA ROBUSTA S18", body: "گزینه‌ای حرفه‌ای برای قدرت، بافت و کرمای فنجان.", image: "/coffee.webp", category: "قهوه سبز", origin: "اوگاندا", moq: "عمده / کانتینری", accent: "#8a7655" },
          { title: "هل سبز", subtitle: "GREEN CARDAMOM", body: "انتخاب گرید براساس رنگ، سایز و شدت رایحه.", image: "/spices.webp", category: "ادویه‌جات", origin: "هند", moq: "عمده", accent: "#709467" },
          { title: "فلفل سیاه", subtitle: "BLACK PEPPER", body: "تعریف محصول براساس دانسیته، رطوبت و تمیزی.", image: "/spices.webp", category: "ادویه‌جات", origin: "هند / ویتنام", moq: "عمده", accent: "#49534d" },
          { title: "زردچوبه", subtitle: "TURMERIC", body: "عرضه برای صنایع غذایی و خطوط بسته‌بندی عمده.", image: "/spices.webp", category: "ادویه‌جات", origin: "هند", moq: "عمده", accent: "#d19b42" },
          { title: "بادام هندی", subtitle: "CASHEW KERNELS", body: "گریدهای منتخب با تعریف شکستگی و بسته‌بندی.", image: "/nuts.webp", category: "خشکبار", origin: "هند / ویتنام", moq: "عمده", accent: "#c49a69" },
          { title: "مغز بادام", subtitle: "ALMOND KERNELS", body: "گزینه‌های مناسب بازار عمده، پخش و فرآوری.", image: "/nuts.webp", category: "خشکبار", origin: "قابل بررسی", moq: "عمده", accent: "#a9835b" },
          { title: "مغز گردو", subtitle: "WALNUT KERNELS", body: "انتخاب براساس رنگ، سایز و درصد شکستگی.", image: "/nuts.webp", category: "خشکبار", origin: "قابل بررسی", moq: "عمده", accent: "#936c43" },
        ],
        visible: true,
        tone: "light",
      },
    ],
  },
  {
    slug: "network",
    title: "شبکه تأمین",
    menuLabel: "شبکه تأمین",
    description: "مدل تأمین و مسیرهای منتخب مبدأ",
    status: "published",
    blocks: [
      hero("network", "شبکه‌ای برای انتخاب بهتر،", "نه فقط مسیر بیشتر.", "از برزیل و ویتنام تا هند، آفریقا و مسیرهای منطقه‌ای؛ هر مبدأ بر اساس محصول و نیاز خرید انتخاب می‌شود."),
      {
        id: "network-text",
        type: "text",
        label: "رویکرد شبکه",
        eyebrow: "ORIGIN INTELLIGENCE",
        title: "هر مبدأ، یک تصمیم تجاری است",
        body: "شبکه تأمین زاگرس برای نمایش روی نقشه ساخته نشده؛ برای مقایسه فصل، ظرفیت، کیفیت، هزینه حمل و ریسک اجرای سفارش ساخته شده است. تیم بازرگانی گزینه‌ها را در یک پرونده قابل فهم به خریدار ارائه می‌کند.",
        visible: true,
        tone: "light",
      },
      {
        id: "network-origins",
        type: "cards",
        label: "مبدأها",
        title: "مسیرهای منتخب",
        items: [
          { title: "برزیل", subtitle: "ARABICA / CONILON", body: "قهوه سبز و رزرو مبدأ" },
          { title: "ویتنام", subtitle: "ROBUSTA / SPICES", body: "قهوه روبوستا و ادویه‌جات" },
          { title: "هند", subtitle: "SPICES / NUTS", body: "ادویه و خشکبار" },
          { title: "اوگاندا", subtitle: "ROBUSTA ORIGIN", body: "قهوه سبز از شرق آفریقا" },
          { title: "کلمبیا", subtitle: "WASHED ARABICA", body: "عربیکای شسته و مسیرهای منتخب" },
          { title: "اندونزی", subtitle: "COFFEE / SPICES", body: "قهوه و کالاهای تخصصی منطقه" },
        ],
        visible: true,
        tone: "soft",
      },
    ],
  },
  {
    slug: "about",
    title: "درباره ما",
    menuLabel: "درباره ما",
    description: "داستان و رویکرد هلدینگ زاگرس",
    status: "published",
    blocks: [
      hero("about", "ریشه در بازار ایران،", "دید به زنجیره جهانی.", "زاگرس یک هلدینگ بازرگانی از اصفهان است که خرید حرفه‌ای کالا را با اطلاعات روشن و کنترل اجرایی به هم متصل می‌کند."),
      {
        id: "about-story",
        type: "text",
        label: "داستان هلدینگ",
        eyebrow: "WHO WE ARE",
        title: "ساختن اعتماد، محموله به محموله",
        body: "کار ما با یک پرسش ساده شروع می‌شود: خریدار دقیقاً چه محصولی، با چه کیفیتی و در چه زمانی نیاز دارد؟ از همین نقطه، تیم زاگرس گزینه‌های مبدأ، نمونه، مشخصات، اسناد و تحویل را در یک فرآیند منسجم پیش می‌برد.",
        visible: true,
        tone: "light",
      },
      {
        id: "about-values",
        type: "cards",
        label: "ارزش‌ها",
        title: "سه اصل کاری",
        items: [
          { title: "شفافیت", subtitle: "CLARITY", body: "مشخصات، زمان و مسئولیت‌ها پیش از تعهد روشن می‌شوند." },
          { title: "کنترل", subtitle: "CONTROL", body: "نمونه، اسناد و حرکت محموله در یک پرونده دنبال می‌شوند." },
          { title: "پاسخ‌گویی", subtitle: "OWNERSHIP", body: "برای هر پرونده، یک میز پاسخ‌گو تا پایان مسیر وجود دارد." },
        ],
        visible: true,
        tone: "soft",
      },
    ],
  },
  {
    slug: "journal",
    title: "مجله بازار",
    menuLabel: "مجله بازار",
    description: "یادداشت‌های تخصصی بازار و تأمین",
    status: "published",
    blocks: [
      hero("journal", "اطلاعات بازار،", "برای تصمیم قابل اجرا.", "یادداشت‌های کوتاه و کاربردی درباره مبدأ، گرید، کنترل کیفیت و مدیریت خرید عمده."),
      {
        id: "journal-posts",
        type: "cards",
        label: "مقالات",
        eyebrow: "MARKET NOTES",
        title: "تازه‌ترین یادداشت‌ها",
        items: [
          { title: "چگونه گرید قهوه سبز را تعریف کنیم؟", subtitle: "قهوه سبز · ۸ دقیقه", body: "یک چارچوب عملی برای تبدیل نیاز رستری به مشخصات خرید." },
          { title: "رزرو مبدأ یا موجودی منطقه‌ای؟", subtitle: "تأمین · ۶ دقیقه", body: "مقایسه سرعت، ریسک و هزینه در دو مدل خرید." },
          { title: "پرونده کنترل محموله چیست؟", subtitle: "کیفیت · ۵ دقیقه", body: "چطور نمونه، اسناد و مشخصات در یک جریان کنترل می‌شوند." },
          { title: "راهنمای انتخاب روبوستا برای بلِند اسپرسو", subtitle: "قهوه سبز · ۷ دقیقه", body: "اسکرین، دانسیته، عیوب و نقش روبوستا در ساختار فنجان." },
          { title: "هل سبز را با چه شاخص‌هایی بخریم؟", subtitle: "ادویه‌جات · ۶ دقیقه", body: "رنگ، سایز، رایحه، رطوبت و بسته‌بندی در خرید عمده." },
          { title: "کنترل کیفیت خشکبار پیش از حمل", subtitle: "خشکبار · ۵ دقیقه", body: "سایز، شکستگی، رنگ و اسناد لازم برای یک خرید مطمئن." },
        ],
        visible: true,
        tone: "light",
      },
    ],
  },
  {
    slug: "contact",
    title: "تماس و استعلام",
    menuLabel: "تماس با ما",
    description: "شروع یک درخواست تأمین جدید",
    status: "published",
    blocks: [
      hero("contact", "شرح خریدتان را بفرستید؛", "ما مسیر را روشن می‌کنیم.", "نام محصول، حجم، مقصد و زمان تقریبی تحویل برای شروع کافی است."),
      {
        id: "contact-steps",
        type: "cards",
        label: "مراحل تماس",
        title: "شروع همکاری در سه قدم",
        items: [
          { title: "ثبت نیاز", subtitle: "01", body: "محصول، حجم و مقصد را ارسال کنید." },
          { title: "بررسی گزینه‌ها", subtitle: "02", body: "مبدأ، مشخصات و روش تأمین بررسی می‌شود." },
          { title: "دریافت پیشنهاد", subtitle: "03", body: "پیشنهاد تجاری و مسیر بعدی شفاف ارائه می‌شود." },
        ],
        visible: true,
        tone: "soft",
      },
      {
        id: "contact-cta",
        type: "cta",
        label: "اطلاعات تماس",
        eyebrow: "ISFAHAN TRADE DESK",
        title: "میز بازرگانی زاگرس",
        body: "پاسخ‌گویی به درخواست‌های خرید عمده و کانتینری.",
        buttonText: "ارسال ایمیل",
        buttonLink: "mailto:trade@zagrosholding.ir",
        visible: true,
        tone: "brand",
      },
    ],
  },
];

export const blockTemplates: Record<BlockType, Omit<CmsBlock, "id">> = {
  hero: { type: "hero", label: "هدر تصویری", eyebrow: "NEW SECTION", title: "عنوان اصلی", accent: "بخش برجسته", body: "توضیح این بخش را بنویسید.", image: "/isfahan.webp", buttonText: "بیشتر بدانید", buttonLink: "/contact", visible: true, tone: "brand" },
  text: { type: "text", label: "متن", eyebrow: "EDITORIAL", title: "عنوان بخش متنی", body: "متن کامل این بخش را اینجا وارد کنید.", visible: true, tone: "light" },
  stats: { type: "stats", label: "آمار", items: [{ title: "۱۰۰٪", subtitle: "شاخص نمونه" }, { title: "۲۴/۷", subtitle: "پاسخ‌گویی" }], visible: true, tone: "soft" },
  cards: { type: "cards", label: "کارت‌ها", title: "عنوان مجموعه کارت‌ها", body: "توضیح کوتاه", items: [{ title: "کارت جدید", subtitle: "LABEL", body: "توضیح کارت" }], visible: true, tone: "light" },
  image: { type: "image", label: "تصویر", title: "عنوان تصویر", body: "توضیح تصویر", image: "/zagros-holding-hero-v2.png", visible: true, tone: "light" },
  video: { type: "video", label: "ویدیو", eyebrow: "BRAND FILM", title: "عنوان ویدیو", body: "توضیح ویدیو", videoUrl: "", image: "/isfahan.webp", autoplay: false, loop: false, muted: true, visible: true, tone: "brand" },
  gallery: { type: "gallery", label: "گالری تصاویر", title: "گالری", body: "تصاویر این مجموعه را مدیریت کنید.", items: [{ title: "تصویر اول", image: "/coffee.webp" }, { title: "تصویر دوم", image: "/spices.webp" }, { title: "تصویر سوم", image: "/nuts.webp" }], visible: true, tone: "light" },
  faq: { type: "faq", label: "سؤالات متداول", title: "سؤالات متداول", body: "پاسخ پرسش‌های مهم خریداران.", items: [{ title: "حداقل سفارش چقدر است؟", body: "حداقل سفارش براساس محصول و مسیر تأمین تعیین می‌شود." }], visible: true, tone: "soft" },
  table: { type: "table", label: "جدول", title: "عنوان جدول", columns: ["ستون اول", "ستون دوم"], rows: [["مقدار اول", "مقدار دوم"]], visible: true, tone: "soft" },
  cta: { type: "cta", label: "دعوت به اقدام", title: "عنوان دعوت به اقدام", body: "توضیح کوتاه", buttonText: "اقدام کنید", buttonLink: "/contact", visible: true, tone: "brand" },
};

export function cloneDefaults(): CmsPage[] {
  return JSON.parse(JSON.stringify(defaultPages)) as CmsPage[];
}
