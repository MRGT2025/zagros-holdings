import { defaultPages, defaultSettings, type AdminRecord, type CmsPage, type CmsSettings } from "./cms";
import { getCmsEnv } from "../../worker/cms-env";
import { getCloudflareRequestUser } from "../cloudflare-auth";

export { getCmsEnv };

export async function ensureCms() {
  const db = getCmsEnv().DB;
  if (!db) throw new Error("پایگاه داده سایت در دسترس نیست.");

  await db.batch([
    db.prepare(`CREATE TABLE IF NOT EXISTS admins (
      id TEXT PRIMARY KEY,
      email TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL DEFAULT '',
      role TEXT NOT NULL DEFAULT 'editor',
      status TEXT NOT NULL DEFAULT 'pending',
      created_at INTEGER NOT NULL
    )`),
    db.prepare(`CREATE TABLE IF NOT EXISTS pages (
      slug TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      menu_label TEXT NOT NULL,
      description TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'draft',
      content_json TEXT NOT NULL,
      updated_at INTEGER NOT NULL,
      updated_by TEXT NOT NULL DEFAULT ''
    )`),
    db.prepare(`CREATE TABLE IF NOT EXISTS page_revisions (
      id TEXT PRIMARY KEY,
      page_slug TEXT NOT NULL,
      content_json TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      created_by TEXT NOT NULL DEFAULT ''
    )`),
    db.prepare(`CREATE TABLE IF NOT EXISTS site_settings (
      setting_key TEXT PRIMARY KEY,
      value_json TEXT NOT NULL,
      updated_at INTEGER NOT NULL
    )`),
    db.prepare(`CREATE TABLE IF NOT EXISTS media (
      id TEXT PRIMARY KEY,
      object_key TEXT NOT NULL UNIQUE,
      filename TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      size INTEGER NOT NULL,
      uploaded_by TEXT NOT NULL,
      created_at INTEGER NOT NULL
    )`),
    db.prepare("CREATE INDEX IF NOT EXISTS page_revisions_slug_idx ON page_revisions(page_slug, created_at DESC)"),
    db.prepare("CREATE INDEX IF NOT EXISTS media_created_idx ON media(created_at DESC)"),
  ]);

  const ownerEmail = (getCmsEnv().OWNER_EMAIL || "info@mrgt.co").trim().toLowerCase();
  if (!/^\S+@\S+\.\S+$/.test(ownerEmail)) throw new Error("OWNER_EMAIL معتبر نیست.");
  await db.prepare(`INSERT INTO admins (id, email, name, role, status, created_at)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(email) DO UPDATE SET role = 'owner', status = 'active'`)
    .bind(crypto.randomUUID(), ownerEmail, "مالک زاگرس", "owner", "active", Date.now()).run();

  const count = await db.prepare("SELECT COUNT(*) AS count FROM pages").first<{ count: number }>();
  if (!count?.count) {
    const now = Date.now();
    await db.batch(defaultPages.map((page) => db.prepare(`INSERT INTO pages (slug, title, menu_label, description, status, content_json, updated_at, updated_by)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
      .bind(page.slug, page.title, page.menuLabel, page.description, page.status, JSON.stringify(page.blocks), now, "system")));
  }

  const contentVersion = await db.prepare("SELECT value_json FROM site_settings WHERE setting_key = ?").bind("content_schema_version").first<{ value_json: string }>();
  if (contentVersion?.value_json !== "3") {
    const now = Date.now();
    const existing = await db.prepare("SELECT slug, content_json FROM pages").all<{ slug: string; content_json: string }>();
    const revisionWrites = existing.results.map((page) => db.prepare("INSERT INTO page_revisions (id, page_slug, content_json, created_at, created_by) VALUES (?, ?, ?, ?, ?)")
      .bind(crypto.randomUUID(), page.slug, page.content_json, now, "theme-upgrade-v3"));
    const pageWrites = defaultPages.map((page) => db.prepare(`INSERT INTO pages (slug, title, menu_label, description, status, content_json, updated_at, updated_by)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(slug) DO UPDATE SET title = excluded.title, menu_label = excluded.menu_label, description = excluded.description, status = excluded.status, content_json = excluded.content_json, updated_at = excluded.updated_at, updated_by = excluded.updated_by`)
      .bind(page.slug, page.title, page.menuLabel, page.description, page.status, JSON.stringify(page.blocks), now, "theme-upgrade-v3"));
    await db.batch([...revisionWrites, ...pageWrites, db.prepare(`INSERT INTO site_settings (setting_key, value_json, updated_at) VALUES (?, ?, ?)
      ON CONFLICT(setting_key) DO UPDATE SET value_json = excluded.value_json, updated_at = excluded.updated_at`).bind("content_schema_version", "3", now)]);
  }

  const settings = await db.prepare("SELECT setting_key FROM site_settings WHERE setting_key = ?").bind("global").first();
  if (!settings) await db.prepare("INSERT INTO site_settings (setting_key, value_json, updated_at) VALUES (?, ?, ?)").bind("global", JSON.stringify(defaultSettings), Date.now()).run();
}

export async function getPages({ publishedOnly = false }: { publishedOnly?: boolean } = {}): Promise<CmsPage[]> {
  await ensureCms();
  const ordering = "ORDER BY CASE slug WHEN 'home' THEN 1 WHEN 'products' THEN 2 WHEN 'shop' THEN 3 WHEN 'about' THEN 4 WHEN 'network' THEN 5 WHEN 'journal' THEN 6 WHEN 'contact' THEN 7 ELSE 99 END, rowid ASC";
  const query = publishedOnly
    ? getCmsEnv().DB.prepare(`SELECT * FROM pages WHERE status = ? ${ordering}`).bind("published")
    : getCmsEnv().DB.prepare(`SELECT * FROM pages ${ordering}`);
  const result = await query.all<Record<string, unknown>>();
  return result.results.map((row) => ({
    slug: String(row.slug),
    title: String(row.title),
    menuLabel: String(row.menu_label),
    description: String(row.description),
    status: row.status === "published" ? "published" : "draft",
    blocks: JSON.parse(String(row.content_json)),
    updatedAt: Number(row.updated_at),
  }));
}

export async function getSettings(): Promise<CmsSettings> {
  await ensureCms();
  const row = await getCmsEnv().DB.prepare("SELECT value_json FROM site_settings WHERE setting_key = ?").bind("global").first<{ value_json: string }>();
  return row ? { ...defaultSettings, ...JSON.parse(row.value_json) } : defaultSettings;
}

export async function getAdmins(): Promise<AdminRecord[]> {
  await ensureCms();
  const result = await getCmsEnv().DB.prepare("SELECT * FROM admins ORDER BY created_at ASC").all<Record<string, unknown>>();
  return result.results.map((row) => ({ id: String(row.id), email: String(row.email), name: String(row.name), role: String(row.role) as AdminRecord["role"], status: String(row.status) as AdminRecord["status"], createdAt: Number(row.created_at) }));
}

export async function requireCmsAdmin(request: Request): Promise<AdminRecord> {
  await ensureCms();
  const identity = await getCloudflareRequestUser(request);
  if (!identity) throw new Response(JSON.stringify({ error: "برای ورود به مدیریت، ابتدا وارد حساب خود شوید." }), { status: 401, headers: { "content-type": "application/json" } });
  const db = getCmsEnv().DB;
  let row = await db.prepare("SELECT * FROM admins WHERE lower(email) = ?").bind(identity.email).first<Record<string, unknown>>();
  if (!row) throw new Response(JSON.stringify({ error: "این ایمیل در فهرست مدیران سایت نیست." }), { status: 403, headers: { "content-type": "application/json" } });
  if (row.status !== "active") {
    await db.prepare("UPDATE admins SET status = ?, name = ? WHERE id = ?").bind("active", identity.name || String(row.name), String(row.id)).run();
    row = { ...row, status: "active", name: identity.name || String(row.name) };
  }
  return { id: String(row.id), email: String(row.email), name: String(row.name), role: String(row.role) as AdminRecord["role"], status: String(row.status) as AdminRecord["status"], createdAt: Number(row.created_at) };
}

export function canEdit(admin: AdminRecord) {
  return admin.role === "owner" || admin.role === "admin" || admin.role === "editor";
}

export function canManageAdmins(admin: AdminRecord) {
  return admin.role === "owner" || admin.role === "admin";
}
