import { createRemoteJWKSet, jwtVerify } from "jose";
import { headers } from "next/headers";
import { getCmsEnv } from "../worker/cms-env";

export type CloudflareUser = {
  displayName: string;
  email: string;
  name: string;
};

const jwksCache = new Map<string, ReturnType<typeof createRemoteJWKSet>>();

function localPreviewUser(hostname: string): CloudflareUser | null {
  if (!["terminal.local", "localhost", "127.0.0.1"].includes(hostname)) return null;
  return {
    displayName: "پیش‌نمایش مدیر",
    email: (getCmsEnv().OWNER_EMAIL || "info@mrgt.co").trim().toLowerCase(),
    name: "پیش‌نمایش مدیر",
  };
}

function teamOrigin(value: string): string {
  const normalized = value.trim().replace(/\/$/, "");
  return normalized.startsWith("https://") ? normalized : `https://${normalized}`;
}

async function verifyAccessHeaders(requestHeaders: Headers, hostname: string): Promise<CloudflareUser | null> {
  const preview = localPreviewUser(hostname);
  if (preview) return preview;

  const { CF_ACCESS_AUD, CF_ACCESS_TEAM_DOMAIN } = getCmsEnv();
  const token = requestHeaders.get("cf-access-jwt-assertion");
  if (!token || !CF_ACCESS_AUD || !CF_ACCESS_TEAM_DOMAIN) return null;

  const issuer = teamOrigin(CF_ACCESS_TEAM_DOMAIN);
  let jwks = jwksCache.get(issuer);
  if (!jwks) {
    jwks = createRemoteJWKSet(new URL(`${issuer}/cdn-cgi/access/certs`));
    jwksCache.set(issuer, jwks);
  }

  try {
    const { payload } = await jwtVerify(token, jwks, {
      issuer,
      audience: CF_ACCESS_AUD,
    });
    const email = typeof payload.email === "string" ? payload.email.trim().toLowerCase() : "";
    if (!/^\S+@\S+\.\S+$/.test(email)) return null;
    const name = typeof payload.name === "string" && payload.name.trim() ? payload.name.trim() : email;
    return { email, name, displayName: name };
  } catch {
    return null;
  }
}

export async function getCloudflareRequestUser(request: Request): Promise<CloudflareUser | null> {
  return verifyAccessHeaders(request.headers, new URL(request.url).hostname);
}

export async function getCloudflareUser(): Promise<CloudflareUser | null> {
  const requestHeaders = await headers();
  const hostname = (requestHeaders.get("host") || "").split(":")[0];
  return verifyAccessHeaders(requestHeaders, hostname);
}
