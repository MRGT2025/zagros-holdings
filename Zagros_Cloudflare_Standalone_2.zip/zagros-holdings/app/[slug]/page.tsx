import PublicSite from "../components/PublicSite";

const publicSlugs = new Set(["products", "shop", "network", "about", "journal", "contact"]);

export default async function ContentPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  return <PublicSite slug={publicSlugs.has(slug) ? slug : "home"} />;
}
