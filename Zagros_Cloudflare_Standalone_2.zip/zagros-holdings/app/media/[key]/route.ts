import { getCmsEnv } from "../../lib/server-cms";

export async function GET(_request: Request, { params }: { params: Promise<{ key: string }> }) {
  const { key } = await params;
  if (!/^[a-z0-9-]+\.(png|jpg|webp|mp4|webm)$/.test(key)) return new Response("Not found", { status: 404 });
  const object = await getCmsEnv().BUCKET?.get(key);
  if (!object) return new Response("Not found", { status: 404 });
  const headers = new Headers();
  object.writeHttpMetadata(headers);
  headers.set("etag", object.httpEtag);
  headers.set("cache-control", "public, max-age=31536000, immutable");
  return new Response(object.body, { headers });
}
